export type NodeCategory = 'root' | 'branch' | 'concept';

export type StudyStatus = 0 | 1 | 2; // 0: Судлаагүй, 1: Судалж байгаа, 2: Ойлгосон

export interface GraphNode {
  i: string; // ID
  p?: string; // Parent ID
  t: string; // Mongolian Title
  e?: string; // English scientific title
  d: string; // Description / Details
  r?: string; // Optional reference
  f?: string; // Formulas
  c?: string; // Preconditions / Conditions of use
  s?: string; // SPSS walkthrough
  w?: string; // Lecture discrepancy warning
  rl?: string[]; // Related concept IDs
  lv?: number; // Level: 0 for root, 1 for branch, 2 for concept
  n?: string; // Branch number e.g. "01", "02", etc.
  x: number;
  y: number;
  a?: number; // Radial angle
  k?: GraphNode[]; // Children nodes
}

export interface GraphLink {
  source: string;
  target: string;
  cross?: boolean;
}
