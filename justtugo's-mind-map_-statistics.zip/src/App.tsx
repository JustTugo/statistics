import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { buildGraph } from './data/graphData';
import { GraphNode, StudyStatus } from './types';
import { IntellySidebar } from './components/IntellySidebar';
import { IntellyTopNav } from './components/IntellyTopNav';
import { IntellyDashboard } from './components/IntellyDashboard';
import { MindMapCanvas } from './components/MindMapCanvas';
import { ConceptDrawer } from './components/ConceptDrawer';
import { ListView } from './components/ListView';
import { DecisionMatrixModal } from './components/DecisionMatrixModal';
import { CalculatorModal } from './components/CalculatorModal';
import { SearchModal } from './components/SearchModal';
import { BookmarksModal } from './components/BookmarksModal';
import { PWAInstallModal } from './components/PWAInstallModal';
import {
  LayoutDashboard,
  Network,
  ListTree,
  GitFork,
  Calculator,
  Bookmark
} from 'lucide-react';

export default function App() {
  const { nodesMap, nodesList, branches, root } = useMemo(() => buildGraph(), []);

  // Theme state: 'light' | 'dark'
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    try {
      const saved = localStorage.getItem('jt_theme');
      if (saved === 'dark' || saved === 'light') return saved;
    } catch (_) {}
    return 'light';
  });

  const toggleTheme = () => {
    setTheme(prev => {
      const next = prev === 'light' ? 'dark' : 'light';
      try {
        localStorage.setItem('jt_theme', next);
      } catch (_) {}
      return next;
    });
  };

  // View state: 'dashboard' | 'mindmap' | 'list'
  const [currentView, setCurrentView] = useState<'dashboard' | 'mindmap' | 'list'>('dashboard');

  // Mobile sidebar drawer state
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState<boolean>(false);

  // Search input state
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Selected Node & Drawer state
  const [selectedNode, setSelectedNode] = useState<GraphNode | null>(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState<boolean>(false);

  // Expanded branches
  const [expandedBranches, setExpandedBranches] = useState<Set<string>>(() => {
    return new Set(branches.map(b => b.i));
  });

  // Fit signal
  const [fitSignal, setFitSignal] = useState<number>(0);

  // Modals
  const [searchOpen, setSearchOpen] = useState<boolean>(false);
  const [matrixOpen, setMatrixOpen] = useState<boolean>(false);
  const [calcOpen, setCalcOpen] = useState<boolean>(false);
  const [bookmarksOpen, setBookmarksOpen] = useState<boolean>(false);
  const [installModalOpen, setInstallModalOpen] = useState<boolean>(false);

  // Study status & Bookmarks persistent state
  const [st, setSt] = useState<{
    s: Record<string, StudyStatus>;
    b: Record<string, boolean>;
  }>(() => {
    try {
      const saved = localStorage.getItem('jt');
      if (saved) return JSON.parse(saved);
    } catch (_) {}
    return { s: {}, b: {} };
  });

  // Save to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('jt', JSON.stringify(st));
    } catch (_) {}
  }, [st]);

  // Global keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setSearchOpen(true);
      } else if (e.key === 'Escape') {
        setSearchOpen(false);
        setMatrixOpen(false);
        setCalcOpen(false);
        setBookmarksOpen(false);
        setIsDrawerOpen(false);
        setIsMobileMenuOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Handle selecting a node
  const handleSelectNode = useCallback(
    (node: GraphNode, toggleBranch = false) => {
      if (node.lv === 1 && toggleBranch) {
        setExpandedBranches(prev => {
          const next = new Set(prev);
          if (next.has(node.i)) {
            next.delete(node.i);
          } else {
            next.add(node.i);
          }
          return next;
        });
      } else if (node.lv === 2 && node.p) {
        setExpandedBranches(prev => new Set([...prev, node.p!]));
      }

      setSelectedNode(node);
      setIsDrawerOpen(true);
    },
    []
  );

  const handleToggleExpandAll = useCallback(() => {
    setExpandedBranches(prev => {
      if (prev.size === branches.length) {
        return new Set();
      } else {
        return new Set(branches.map(b => b.i));
      }
    });
  }, [branches]);

  const handleChangeStatus = (status: StudyStatus) => {
    if (!selectedNode) return;
    setSt(prev => ({
      ...prev,
      s: {
        ...prev.s,
        [selectedNode.i]: status
      }
    }));
  };

  const handleToggleBookmark = () => {
    if (!selectedNode) return;
    setSt(prev => ({
      ...prev,
      b: {
        ...prev.b,
        [selectedNode.i]: !prev.b[selectedNode.i]
      }
    }));
  };

  const handleClearBookmarks = () => {
    setSt(prev => ({
      ...prev,
      b: {}
    }));
  };

  const bookmarksCount = Object.keys(st.b).filter(k => st.b[k]).length;
  const isDark = theme === 'dark';

  return (
    <div
      style={{
        backgroundColor: isDark ? '#0D0D0D' : '#F3EFE6',
        color: isDark ? '#EDEDED' : '#1C1C1C'
      }}
      className="min-h-screen w-screen flex items-center justify-center p-0 md:p-4 lg:p-6 overflow-hidden transition-colors duration-300"
    >
      {/* Outer Device Enclosure (Responsive for mobile & desktop) */}
      <div
        style={{
          backgroundColor: isDark ? '#161616' : '#FAF7F0',
          borderColor: isDark ? '#2E2E2E' : '#202020'
        }}
        className="w-full max-w-[1540px] h-screen md:h-[94vh] border-0 md:border rounded-none md:rounded-[36px] shadow-[0_25px_60px_rgba(0,0,0,0.12)] flex overflow-hidden relative transition-colors duration-300 flex-col md:flex-row"
      >
        {/* 1. Left Dark Sidebar (Persistent on desktop, drawer on mobile) */}
        <IntellySidebar
          currentView={currentView}
          onChangeView={view => {
            setCurrentView(view);
            setIsMobileMenuOpen(false);
          }}
          onOpenMatrix={() => setMatrixOpen(true)}
          onOpenCalculator={() => setCalcOpen(true)}
          onOpenBookmarks={() => setBookmarksOpen(true)}
          onResetView={() => {
            setCurrentView('dashboard');
            setSelectedNode(root);
            setFitSignal(prev => prev + 1);
          }}
          bookmarksCount={bookmarksCount}
          theme={theme}
          onToggleTheme={toggleTheme}
          isOpenMobile={isMobileMenuOpen}
          onCloseMobile={() => setIsMobileMenuOpen(false)}
          onOpenInstallModal={() => setInstallModalOpen(true)}
        />

        {/* 2. Middle Content Column */}
        <div
          style={{
            backgroundColor: isDark ? '#161616' : '#FAF7F0'
          }}
          className="flex-1 flex flex-col h-full min-h-0 overflow-hidden transition-colors duration-300"
        >
          {/* Top Search & Filter Bar */}
          <IntellyTopNav
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            onOpenSearchModal={() => setSearchOpen(true)}
            currentView={currentView}
            onChangeView={setCurrentView}
            theme={theme}
            onToggleTheme={toggleTheme}
            onOpenMobileMenu={() => setIsMobileMenuOpen(true)}
            onOpenInstallModal={() => setInstallModalOpen(true)}
          />

          {/* Main Workspace Body - min-h-0 and relative enables scroll inside children */}
          <main className="flex-1 min-h-0 relative overflow-hidden">
            {currentView === 'dashboard' ? (
              <IntellyDashboard
                nodesMap={nodesMap}
                nodesList={nodesList}
                branches={branches}
                onSelectNode={node => {
                  setSelectedNode(node);
                  setCurrentView('mindmap');
                  setIsDrawerOpen(true);
                }}
                onOpenMindMap={() => setCurrentView('mindmap')}
                onOpenMatrix={() => setMatrixOpen(true)}
                onOpenCalculator={() => setCalcOpen(true)}
                onOpenBookmarks={() => setBookmarksOpen(true)}
                theme={theme}
              />
            ) : currentView === 'mindmap' ? (
              <MindMapCanvas
                root={root}
                branches={branches}
                nodesMap={nodesMap}
                selectedNode={selectedNode}
                expandedBranches={expandedBranches}
                onSelectNode={handleSelectNode}
                studyStatus={st.s}
                bookmarks={st.b}
                isDrawerOpen={isDrawerOpen}
                fitSignal={fitSignal}
                theme={theme}
                onToggleTheme={toggleTheme}
                onToggleExpandAll={handleToggleExpandAll}
              />
            ) : (
              <ListView
                branches={branches}
                onSelectNode={node => {
                  setSelectedNode(node);
                  setIsDrawerOpen(true);
                }}
                studyStatus={st.s}
                bookmarks={st.b}
                selectedNodeId={selectedNode?.i || null}
                theme={theme}
              />
            )}
          </main>

          {/* Mobile Bottom Navigation Bar (thumb navigation on mobile) */}
          <nav
            style={{
              backgroundColor: isDark ? '#141414' : '#FFFFFF',
              borderColor: isDark ? '#262626' : '#E8E2D5'
            }}
            className="md:hidden border-t px-2 py-1.5 flex items-center justify-around shrink-0 z-30"
          >
            <button
              onClick={() => setCurrentView('dashboard')}
              className={`flex flex-col items-center py-1 px-2.5 rounded-xl transition cursor-pointer ${
                currentView === 'dashboard'
                  ? 'text-[#FF6B8B] font-bold'
                  : 'text-[#888888] hover:text-white'
              }`}
            >
              <LayoutDashboard className="w-4 h-4" />
              <span className="text-[10px] mt-0.5">Нүүр</span>
            </button>

            <button
              onClick={() => setCurrentView('mindmap')}
              className={`flex flex-col items-center py-1 px-2.5 rounded-xl transition cursor-pointer ${
                currentView === 'mindmap'
                  ? 'text-[#64B5F6] font-bold'
                  : 'text-[#888888] hover:text-white'
              }`}
            >
              <Network className="w-4 h-4" />
              <span className="text-[10px] mt-0.5">Зураглал</span>
            </button>

            <button
              onClick={() => setCurrentView('list')}
              className={`flex flex-col items-center py-1 px-2.5 rounded-xl transition cursor-pointer ${
                currentView === 'list'
                  ? 'text-[#FFD54F] font-bold'
                  : 'text-[#888888] hover:text-white'
              }`}
            >
              <ListTree className="w-4 h-4" />
              <span className="text-[10px] mt-0.5">Сэдвүүд</span>
            </button>

            <button
              onClick={() => setMatrixOpen(true)}
              className="flex flex-col items-center py-1 px-2.5 rounded-xl text-[#888888] hover:text-white transition cursor-pointer"
            >
              <GitFork className="w-4 h-4 text-[#81C784]" />
              <span className="text-[10px] mt-0.5">Сонголт</span>
            </button>

            <button
              onClick={() => setCalcOpen(true)}
              className="flex flex-col items-center py-1 px-2.5 rounded-xl text-[#888888] hover:text-white transition cursor-pointer"
            >
              <Calculator className="w-4 h-4 text-[#BA68C8]" />
              <span className="text-[10px] mt-0.5">Тооцоолуур</span>
            </button>

            <button
              onClick={() => setBookmarksOpen(true)}
              className="flex flex-col items-center py-1 px-2.5 rounded-xl text-[#888888] hover:text-white transition cursor-pointer relative"
            >
              <Bookmark className="w-4 h-4 text-[#FFD54F]" />
              <span className="text-[10px] mt-0.5">Хадгалсан</span>
              {bookmarksCount > 0 && (
                <span className="absolute top-0.5 right-1 w-2 h-2 rounded-full bg-[#FF6B8B]" />
              )}
            </button>
          </nav>
        </div>

        {/* Slide-over Detailed Concept Reading Drawer (#panel) */}
        {currentView !== 'dashboard' && selectedNode && (
          <ConceptDrawer
            node={selectedNode}
            nodesMap={nodesMap}
            isOpen={isDrawerOpen}
            onClose={() => setIsDrawerOpen(false)}
            onSelectNode={nodeId => handleSelectNode(nodesMap[nodeId] || root)}
            isBookmarked={Boolean(st.b[selectedNode.i])}
            onToggleBookmark={handleToggleBookmark}
            status={st.s[selectedNode.i] || 0}
            onChangeStatus={handleChangeStatus}
            isFocusMode={false}
            onToggleFocusMode={() => {}}
            theme={theme}
          />
        )}
      </div>

      {/* Decision Matrix Modal */}
      <DecisionMatrixModal
        isOpen={matrixOpen}
        onClose={() => setMatrixOpen(false)}
        nodesMap={nodesMap}
        onSelectNode={handleSelectNode}
      />

      {/* Interactive Calculators Modal */}
      <CalculatorModal
        isOpen={calcOpen}
        onClose={() => setCalcOpen(false)}
      />

      {/* Quick Search Modal */}
      <SearchModal
        isOpen={searchOpen}
        onClose={() => setSearchOpen(false)}
        nodesList={nodesList}
        nodesMap={nodesMap}
        onSelectNode={handleSelectNode}
      />

      {/* Bookmarks Modal */}
      <BookmarksModal
        isOpen={bookmarksOpen}
        onClose={() => setBookmarksOpen(false)}
        bookmarks={st.b}
        nodesMap={nodesMap}
        onSelectNode={handleSelectNode}
        studyStatus={st.s}
        onClearBookmarks={handleClearBookmarks}
      />

      {/* Android & PWA App Install Modal */}
      <PWAInstallModal
        isOpen={installModalOpen}
        onClose={() => setInstallModalOpen(false)}
        theme={theme}
      />
    </div>
  );
}
