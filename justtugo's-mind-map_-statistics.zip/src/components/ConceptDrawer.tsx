import React from 'react';
import { GraphNode, StudyStatus } from '../types';
import { MathFormula } from './MathFormula';
import { X, Bookmark, AlertTriangle } from 'lucide-react';
import confetti from 'canvas-confetti';

interface ConceptDrawerProps {
  node: GraphNode;
  nodesMap: Record<string, GraphNode>;
  isOpen: boolean;
  onClose: () => void;
  onSelectNode: (nodeId: string) => void;
  isBookmarked: boolean;
  onToggleBookmark: () => void;
  status: StudyStatus;
  onChangeStatus: (status: StudyStatus) => void;
  isFocusMode: boolean;
  onToggleFocusMode: () => void;
  theme?: 'light' | 'dark';
}

export const ConceptDrawer: React.FC<ConceptDrawerProps> = ({
  node,
  nodesMap,
  isOpen,
  onClose,
  onSelectNode,
  isBookmarked,
  onToggleBookmark,
  status,
  onChangeStatus,
  isFocusMode,
  theme = 'light'
}) => {
  if (!isOpen) return null;

  const isDark = theme === 'dark';

  // Build breadcrumb trail
  const breadcrumbs: GraphNode[] = [];
  let curr: GraphNode | undefined = node;
  while (curr) {
    breadcrumbs.unshift(curr);
    curr = curr.p ? nodesMap[curr.p] : undefined;
  }

  // Related concepts
  const relatedIds = Array.from(new Set([...(node.rl || []), ...(node.k?.map(c => c.i) || [])]));
  const relatedNodes = relatedIds.map(id => nodesMap[id]).filter(Boolean);

  const handleStatusClick = (newStatus: StudyStatus) => {
    onChangeStatus(newStatus);
    if (newStatus === 2) {
      confetti({
        particleCount: 45,
        spread: 60,
        origin: { y: 0.6 }
      });
    }
  };

  return (
    <aside
      style={{
        backgroundColor: isDark ? '#181818' : '#FAF7F0',
        borderColor: isDark ? '#2E2E2E' : '#EBE5D8',
        color: isDark ? '#EDEDED' : '#141414'
      }}
      className={`absolute top-0 right-0 h-full transition-transform duration-350 ease-out z-40 border-l shadow-2xl flex flex-col ${
        isFocusMode
          ? 'w-full max-w-full px-6 sm:px-16 py-8'
          : 'w-full sm:w-[460px] lg:w-[490px] p-5 sm:p-7'
      } ${isOpen ? 'translate-x-0' : 'translate-x-[105%]'}`}
    >
      {/* Top action row */}
      <div
        style={{ borderColor: isDark ? '#2E2E2E' : '#EBE5D8' }}
        className="flex items-center justify-between pb-4 border-b shrink-0"
      >
        <button
          onClick={onClose}
          className="px-4 py-1.5 rounded-full bg-[#141414] hover:bg-black text-white text-xs font-semibold transition cursor-pointer flex items-center shadow-xs"
        >
          <span>Хаах</span>
        </button>

        <div className="flex items-center space-x-2">
          <button
            onClick={onToggleBookmark}
            style={{
              backgroundColor: isBookmarked
                ? '#FAD968'
                : isDark
                ? '#242424'
                : '#FFFFFF',
              borderColor: isBookmarked
                ? '#E5C250'
                : isDark
                ? '#383838'
                : '#E2D9CC',
              color: isBookmarked ? '#141414' : isDark ? '#EDEDED' : '#777777'
            }}
            className="p-2 rounded-full border transition cursor-pointer flex items-center justify-center"
            title="Хадгалах"
          >
            <Bookmark className={`w-3.5 h-3.5 ${isBookmarked ? 'fill-[#141414]' : ''}`} />
          </button>
        </div>
      </div>

      {/* Breadcrumb path */}
      <div className="pt-3 text-xs font-mono text-[#888888] flex flex-wrap items-center gap-1.5 shrink-0">
        {breadcrumbs.map((b, idx) => (
          <React.Fragment key={b.i}>
            {idx > 0 && <span className="text-[#AAAAAA]">/</span>}
            <button
              onClick={() => onSelectNode(b.i)}
              className={`hover:opacity-80 transition cursor-pointer ${
                b.i === node.i
                  ? (isDark ? 'text-white font-bold' : 'text-[#141414] font-bold')
                  : 'text-[#888888]'
              }`}
            >
              {b.t}
            </button>
          </React.Fragment>
        ))}
      </div>

      {/* Title & English term */}
      <div className="mt-3 shrink-0">
        <h2 className="text-2xl font-extrabold tracking-tight leading-snug font-sans">
          {node.t}
        </h2>
        {node.e && <div className="text-xs font-mono text-[#888888] mt-0.5">{node.e}</div>}
      </div>

      {/* Study Status Button Group */}
      <div className="mt-4 flex flex-wrap items-center gap-1.5 shrink-0">
        {(['Судлаагүй', 'Судалж байгаа', 'Ойлгосон'] as const).map((label, idx) => (
          <button
            key={label}
            onClick={() => handleStatusClick(idx as StudyStatus)}
            style={{
              backgroundColor:
                status === idx
                  ? isDark
                    ? '#FFFFFF'
                    : '#141414'
                  : isDark
                  ? '#222222'
                  : '#FFFFFF',
              color:
                status === idx
                  ? isDark
                    ? '#141414'
                    : '#FFFFFF'
                  : isDark
                  ? '#AAAAAA'
                  : '#666666',
              borderColor:
                status === idx
                  ? isDark
                    ? '#FFFFFF'
                    : '#141414'
                  : isDark
                  ? '#383838'
                  : '#E0D8C8'
            }}
            className="px-3 py-1.5 rounded-full text-xs font-semibold border transition cursor-pointer"
          >
            {label}
          </button>
        ))}
      </div>

      {/* Main Scrollable Content */}
      <div className="mt-5 flex-1 overflow-y-auto space-y-5 text-sm leading-relaxed pr-1 overscroll-contain">
        {/* Description / Summary */}
        {node.d && (
          <div>
            <div className="text-[10px] font-mono tracking-wider uppercase text-[#888888] mb-1.5 font-bold">
              ТОВЧ ОЙЛГОЛТ
            </div>
            <p
              style={{
                backgroundColor: isDark ? '#222222' : '#FFFFFF',
                borderColor: isDark ? '#333333' : '#EBE5D8',
                color: isDark ? '#EDEDED' : '#141414'
              }}
              className="text-xs sm:text-sm whitespace-pre-line leading-relaxed p-4 rounded-2xl border shadow-2xs"
            >
              {node.d}
            </p>
          </div>
        )}

        {/* Formulas */}
        {node.f && (
          <div>
            <div className="text-[10px] font-mono tracking-wider uppercase text-[#888888] mb-1.5 font-bold">
              ТОМЪЁО
            </div>
            <div
              style={{
                backgroundColor: isDark ? '#2A1D24' : '#F8C8DD/40',
                borderColor: isDark ? '#5C243B' : '#F2B0CC',
                color: isDark ? '#FFFFFF' : '#141414'
              }}
              className="border rounded-2xl p-4 font-mono text-xs text-center shadow-2xs"
            >
              <MathFormula formula={node.f} displayMode={true} />
            </div>
          </div>
        )}

        {/* Conditions of Use */}
        {node.c && (
          <div>
            <div className="text-[10px] font-mono tracking-wider uppercase text-[#888888] mb-1.5 font-bold">
              ТАВИГДАХ ШАЛГУУР (ASSUMPTIONS)
            </div>
            <p
              style={{
                backgroundColor: isDark ? '#222222' : '#FFFFFF',
                borderColor: isDark ? '#333333' : '#EBE5D8',
                color: isDark ? '#D6D6D6' : '#333333'
              }}
              className="text-xs whitespace-pre-line leading-relaxed border rounded-2xl p-4 shadow-2xs"
            >
              {node.c}
            </p>
          </div>
        )}

        {/* SPSS Walkthrough */}
        {node.s && (
          <div>
            <div className="text-[10px] font-mono tracking-wider uppercase text-[#888888] mb-1.5 font-bold">
              SPSS ДЭЭР ХИЙХ ДАРААЛАЛ
            </div>
            <div className="bg-[#141414] text-[#E0E0E0] border border-[#2E2E2E] rounded-2xl p-4 font-mono text-xs leading-relaxed shadow-xs">
              {node.s}
            </div>
          </div>
        )}

        {/* Discrepancy / Warning Flag */}
        {node.w && (
          <div
            style={{
              backgroundColor: isDark ? '#2D1820' : '#F8C8DD/30',
              borderColor: isDark ? '#6B2A40' : '#F0A9C6',
              color: isDark ? '#FFB4C8' : '#441122'
            }}
            className="border rounded-2xl p-4 text-xs leading-relaxed flex items-start space-x-2.5"
          >
            <AlertTriangle className="w-4 h-4 text-[#FF6B8B] shrink-0 mt-0.5" />
            <div>
              <b className={isDark ? 'text-white' : 'text-[#141414]'}>
                Анхаарах зөрүү ба санамж:{' '}
              </b>
              <span>{node.w}</span>
            </div>
          </div>
        )}

        {/* Related Concepts */}
        {relatedNodes.length > 0 && (
          <div>
            <div className="text-[10px] font-mono tracking-wider uppercase text-[#888888] mb-1.5 font-bold">
              ХОЛБООТОЙ ОЙЛГОЛТУУД
            </div>
            <div className="flex flex-wrap gap-1.5">
              {relatedNodes.map(m => (
                <button
                  key={m.i}
                  onClick={() => onSelectNode(m.i)}
                  style={{
                    backgroundColor: isDark ? '#222222' : '#FFFFFF',
                    borderColor: isDark ? '#383838' : '#E0D8C8',
                    color: isDark ? '#EDEDED' : '#141414'
                  }}
                  className="px-3 py-1.5 rounded-full border text-xs font-medium transition cursor-pointer hover:opacity-80"
                >
                  {m.t}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </aside>
  );
};
