import React from 'react';
import { Search, Network, List, GitFork, Calculator, Bookmark, Focus } from 'lucide-react';
import { StudyStatus } from '../types';

interface HeaderProps {
  onOpenSearch: () => void;
  onOpenMatrix: () => void;
  onOpenCalculator: () => void;
  onOpenBookmarks: () => void;
  onToggleViewMode: () => void;
  onGoHome: () => void;
  onGoMindMap: () => void;
  isListView: boolean;
  bookmarksCount: number;
  studyStatus: Record<string, StudyStatus>;
  totalNodes: number;
  isFocusMode: boolean;
  onToggleFocusMode: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenSearch,
  onOpenMatrix,
  onOpenCalculator,
  onOpenBookmarks,
  onToggleViewMode,
  onGoHome,
  onGoMindMap,
  isListView,
  bookmarksCount,
  studyStatus,
  totalNodes,
  isFocusMode,
  onToggleFocusMode
}) => {
  if (isFocusMode) {
    return (
      <header className="fixed top-3 left-4 z-40">
        <button
          onClick={onToggleFocusMode}
          className="px-3 py-1.5 rounded-lg bg-[#1e1e1e]/90 hover:bg-[#282828] text-[#F2F2F2] border border-[#333333] text-xs font-mono backdrop-blur-md transition flex items-center space-x-1.5 cursor-pointer shadow-xl"
        >
          <span>Төвлөрөх горимоос гарах</span>
        </button>
      </header>
    );
  }

  const understoodCount = Object.values(studyStatus).filter(s => s === 2).length;

  return (
    <header className="h-14 z-40 flex items-center justify-between px-4 sm:px-6 bg-[#141414]/90 backdrop-blur-md border-b border-[#282828] shrink-0 select-none">
      {/* Brand logo & title */}
      <div className="flex items-center space-x-3 sm:space-x-4">
        <button
          onClick={onGoHome}
          className="font-bold tracking-[0.14em] text-sm sm:text-base text-[#F2F2F2] hover:text-white transition cursor-pointer flex items-center space-x-2"
        >
          <span>BY JUSTTUGO.</span>
        </button>
        <span className="text-[10px] sm:text-xs px-2 py-0.5 rounded border border-[#333333] bg-[#1e1e1e] text-[#A0A0A0] font-mono">
          MIND MAP: STATS
        </span>
        <div className="hidden lg:flex items-center space-x-2 text-xs text-[#707070] border-l border-[#282828] pl-4">
          <span>ХИС • СЭТГЭЛ СУДЛАЛ</span>
          <span>•</span>
          <span className="text-[#909090]">PSY320 & PSY321</span>
        </div>
      </div>

      {/* Main Navigation Links */}
      <nav className="flex items-center space-x-1 sm:space-x-2 text-xs">
        <button
          onClick={onGoMindMap}
          className={`px-3 py-1.5 rounded-md transition cursor-pointer flex items-center space-x-1.5 ${
            !isListView
              ? 'bg-[#222222] text-[#F2F2F2] font-semibold border border-[#383838]'
              : 'text-[#888888] hover:text-[#F2F2F2]'
          }`}
        >
          <Network className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Оюуны зураглал</span>
        </button>

        <button
          onClick={onToggleViewMode}
          className={`px-3 py-1.5 rounded-md transition cursor-pointer flex items-center space-x-1.5 ${
            isListView
              ? 'bg-[#222222] text-[#F2F2F2] font-semibold border border-[#383838]'
              : 'text-[#888888] hover:text-[#F2F2F2]'
          }`}
        >
          <List className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Бүх сэдэв</span>
        </button>

        <button
          onClick={onOpenMatrix}
          className="px-2.5 py-1.5 rounded-md text-[#888888] hover:text-[#F2F2F2] transition cursor-pointer hidden md:flex items-center space-x-1"
        >
          <GitFork className="w-3.5 h-3.5" />
          <span>Шинжилгээний мод</span>
        </button>

        <button
          onClick={onOpenCalculator}
          className="px-2.5 py-1.5 rounded-md text-[#888888] hover:text-[#F2F2F2] transition cursor-pointer hidden md:flex items-center space-x-1"
        >
          <Calculator className="w-3.5 h-3.5" />
          <span>Тооцоолуур</span>
        </button>
      </nav>

      {/* Right Controls */}
      <div className="flex items-center space-x-2 text-xs">
        {/* Search trigger */}
        <button
          onClick={onOpenSearch}
          className="flex items-center space-x-1.5 px-3 py-1.5 rounded-md border border-[#333333] bg-[#1c1c1c] hover:bg-[#252525] text-[#A0A0A0] hover:text-white transition cursor-pointer"
          title="Хайлт (Ctrl+K)"
        >
          <Search className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Хайх</span>
          <kbd className="hidden lg:inline-block px-1 rounded bg-[#252525] text-[9px] font-mono text-[#777777] border border-[#333333]">
            ⌘K
          </kbd>
        </button>

        {/* Matrix trigger for mobile */}
        <button
          onClick={onOpenMatrix}
          className="p-1.5 rounded-md border border-[#333333] bg-[#1c1c1c] hover:bg-[#252525] text-[#A0A0A0] hover:text-white transition cursor-pointer md:hidden"
          title="Шинжилгээний мод"
        >
          <GitFork className="w-3.5 h-3.5" />
        </button>

        {/* Calculator trigger for mobile */}
        <button
          onClick={onOpenCalculator}
          className="p-1.5 rounded-md border border-[#333333] bg-[#1c1c1c] hover:bg-[#252525] text-[#A0A0A0] hover:text-white transition cursor-pointer md:hidden"
          title="Тооцоолуур"
        >
          <Calculator className="w-3.5 h-3.5" />
        </button>

        {/* Bookmarks */}
        <button
          onClick={onOpenBookmarks}
          className="relative p-1.5 rounded-md border border-[#333333] bg-[#1c1c1c] hover:bg-[#252525] text-[#A0A0A0] hover:text-white transition cursor-pointer"
          title="Хадгалсан сэдвүүд"
        >
          <Bookmark className="w-3.5 h-3.5" />
          {bookmarksCount > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-yellow-500 text-[#141414] font-bold text-[9px] rounded-full flex items-center justify-center">
              {bookmarksCount}
            </span>
          )}
        </button>

        {/* Focus Mode */}
        <button
          onClick={onToggleFocusMode}
          className="p-1.5 rounded-md border border-[#333333] bg-[#1c1c1c] hover:bg-[#252525] text-[#A0A0A0] hover:text-white transition cursor-pointer hidden sm:block"
          title="Төвлөрөх горим"
        >
          <Focus className="w-3.5 h-3.5" />
        </button>
      </div>
    </header>
  );
};
