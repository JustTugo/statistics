import React from 'react';
import { GraphNode, StudyStatus } from '../types';
import { Bookmark, CheckCircle2, Sparkles, BookOpen } from 'lucide-react';

interface ListViewProps {
  branches: GraphNode[];
  onSelectNode: (node: GraphNode) => void;
  studyStatus: Record<string, StudyStatus>;
  bookmarks: Record<string, boolean>;
  selectedNodeId: string | null;
  theme?: 'light' | 'dark';
}

export const ListView: React.FC<ListViewProps> = ({
  branches,
  onSelectNode,
  studyStatus,
  bookmarks,
  selectedNodeId,
  theme = 'light'
}) => {
  const isDark = theme === 'dark';

  return (
    <div
      style={{
        backgroundColor: isDark ? '#161616' : '#FAF7F0',
        color: isDark ? '#EDEDED' : '#141414'
      }}
      className="absolute inset-0 overflow-y-auto p-4 sm:p-8 space-y-6 transition-colors duration-300"
    >
      <div className="max-w-4xl mx-auto space-y-6 pb-12">
        {/* Editorial Overview Card */}
        <div
          style={{
            backgroundColor: isDark ? '#1F1F1F' : '#FFFFFF',
            borderColor: isDark ? '#333333' : '#EBE5D8'
          }}
          className="p-6 rounded-[28px] border shadow-xs"
        >
          <div className="flex items-center space-x-2 text-xs font-mono text-[#888888] tracking-widest uppercase mb-2">
            <Sparkles className="w-3.5 h-3.5 text-[#D81B60]" />
            <span>СТАТИСТИКИЙГ ОЙЛГОХ ШИНЭ АРГА · BY JUSTTUGO</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight mb-2">
            JustTugo's Statistic
          </h1>
          <p
            style={{ color: isDark ? '#A0A0A0' : '#666666' }}
            className="text-xs sm:text-sm leading-relaxed max-w-2xl font-normal"
          >
            Статистик болон судалгааны аргуудыг хоорондын уялдаа холбоогоор нь ойлгож,
            интерактив оюуны зураглалаар суралцаарай. Доорх 9 үндсэн салбараас хүссэн сэдвээ сонгон
            дэлгэрэнгүй тайлбар, томьёо, шалгуур болон SPSS зааврыг харна уу.
          </p>
        </div>

        <div
          style={{ borderColor: isDark ? '#333333' : '#EBE5D8' }}
          className="pb-2 border-b flex items-center justify-between"
        >
          <div className="flex items-center space-x-2">
            <BookOpen className="w-4 h-4 text-[#888888]" />
            <h2 className="text-base sm:text-lg font-bold tracking-tight">
              Бүх салбар ба сэдвүүдийн жагсаалт
            </h2>
          </div>
          <span className="text-xs font-mono text-[#888888]">
            9 салбар • 60+ сэдэв
          </span>
        </div>

        <div className="space-y-3">
          {branches.map(branch => {
            const children = branch.k || [];
            return (
              <details
                key={branch.i}
                open={false}
                style={{
                  backgroundColor: isDark ? '#1E1E1E' : '#FFFFFF',
                  borderColor: isDark ? '#333333' : '#EBE5D8'
                }}
                className="border rounded-[20px] overflow-hidden transition group shadow-2xs"
              >
                <summary
                  style={{
                    backgroundColor: isDark ? '#1E1E1E' : '#FFFFFF'
                  }}
                  className="p-4 cursor-pointer font-semibold text-sm sm:text-base flex items-center justify-between transition hover:opacity-90"
                >
                  <div className="flex items-center space-x-3">
                    <span
                      style={{
                        backgroundColor: isDark ? '#2D2D2D' : '#EBE5D8',
                        color: isDark ? '#FFFFFF' : '#141414'
                      }}
                      className="font-mono text-xs font-bold px-2.5 py-0.5 rounded-full"
                    >
                      {branch.n}
                    </span>
                    <span>{branch.t}</span>
                    {branch.e && (
                      <span className="text-xs text-[#888888] font-mono hidden sm:inline">
                        ({branch.e})
                      </span>
                    )}
                  </div>
                  <div className="text-xs font-mono text-[#888888]">
                    {children.length} сэдэв
                  </div>
                </summary>

                <div
                  style={{
                    backgroundColor: isDark ? '#161616' : '#FAF7F0',
                    borderColor: isDark ? '#333333' : '#EBE5D8'
                  }}
                  className="p-3 border-t space-y-1.5"
                >
                  {children.map(child => {
                    const isSelected = selectedNodeId === child.i;
                    const status = studyStatus[child.i] || 0;
                    const isBookmarked = Boolean(bookmarks[child.i]);

                    return (
                      <button
                        key={child.i}
                        onClick={() => onSelectNode(child)}
                        style={{
                          backgroundColor: isSelected
                            ? (isDark ? '#333333' : '#141414')
                            : (isDark ? '#222222' : '#FFFFFF'),
                          color: isSelected ? '#FFFFFF' : (isDark ? '#EDEDED' : '#333333'),
                          borderColor: isDark ? '#383838' : '#EBE5D8'
                        }}
                        className="w-full text-left px-3.5 py-2.5 rounded-xl flex items-center justify-between transition cursor-pointer text-xs sm:text-sm border"
                      >
                        <div className="flex items-center space-x-2.5 truncate pr-2">
                          <span
                            className={`w-2 h-2 rounded-full shrink-0 ${
                              status === 2
                                ? 'bg-green-500'
                                : status === 1
                                ? 'bg-amber-500'
                                : 'bg-[#777777]'
                            }`}
                          />
                          <span className="font-medium truncate">{child.t}</span>
                          {child.e && (
                            <span
                              className={`text-[11px] font-mono hidden sm:inline truncate ${
                                isSelected ? 'text-[#AAAAAA]' : 'text-[#888888]'
                              }`}
                            >
                              ({child.e})
                            </span>
                          )}
                        </div>

                        <div className="flex items-center space-x-2 shrink-0">
                          {child.f && (
                            <span
                              style={{
                                backgroundColor: isDark ? '#2D2D2D' : '#EBE5D8',
                                color: isDark ? '#B0B0B0' : '#666666'
                              }}
                              className="text-[10px] font-mono px-1.5 py-0.5 rounded hidden md:inline"
                            >
                              fx
                            </span>
                          )}
                          {child.s && (
                            <span
                              style={{
                                backgroundColor: isDark ? '#2D2D2D' : '#EBE5D8',
                                color: isDark ? '#B0B0B0' : '#666666'
                              }}
                              className="text-[10px] font-mono px-1.5 py-0.5 rounded hidden md:inline"
                            >
                              SPSS
                            </span>
                          )}
                          {isBookmarked && (
                            <Bookmark className="w-3.5 h-3.5 text-yellow-500 fill-yellow-500" />
                          )}
                          {status === 2 && (
                            <CheckCircle2 className="w-3.5 h-3.5 text-green-500" />
                          )}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </details>
            );
          })}
        </div>
      </div>
    </div>
  );
};
