import React, { useState, useEffect, useRef } from 'react';
import { GraphNode } from '../types';
import { Search, CornerDownLeft, X } from 'lucide-react';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  nodesList: GraphNode[];
  nodesMap: Record<string, GraphNode>;
  onSelectNode: (node: GraphNode) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  nodesList,
  nodesMap,
  onSelectNode
}) => {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setQuery('');
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const q = query.trim().toLowerCase();

  const pathOf = (node: GraphNode): string => {
    const parts: string[] = [];
    let curr: GraphNode | undefined = node.p ? nodesMap[node.p] : undefined;
    while (curr && curr.i !== 'stat') {
      parts.unshift(curr.t);
      curr = curr.p ? nodesMap[curr.p] : undefined;
    }
    return parts.join(' › ');
  };

  const results = nodesList
    .filter(n => {
      if (!q) return true;
      const haystack = `${n.t} ${n.e || ''} ${n.d}`.toLowerCase();
      return haystack.includes(q);
    })
    .sort((a, b) => {
      const aTitle = a.t.toLowerCase().includes(q) || (a.e || '').toLowerCase().includes(q);
      const bTitle = b.t.toLowerCase().includes(q) || (b.e || '').toLowerCase().includes(q);
      return Number(bTitle) - Number(aTitle);
    })
    .slice(0, 10);

  const handleSelect = (node: GraphNode) => {
    onSelectNode(node);
    onClose();
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-start justify-center pt-20 px-4 select-none"
    >
      <div
        onClick={e => e.stopPropagation()}
        className="w-full max-w-xl bg-[#FAF7F0] border border-[#202020] rounded-[28px] shadow-2xl overflow-hidden flex flex-col max-h-[75vh]"
      >
        <div className="p-4 border-b border-[#EBE5D8] flex items-center space-x-3 bg-[#F0E9DF]">
          <div className="w-7 h-7 rounded-full bg-[#F282B4] flex items-center justify-center text-white shrink-0">
            <Search className="w-3.5 h-3.5 stroke-[2.5]" />
          </div>
          <input
            ref={inputRef}
            type="search"
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Хайх: ANOVA, Хи квадрат, SPSS, корреляци, z оноо..."
            className="w-full bg-transparent text-sm text-[#141414] placeholder:text-[#888888] focus:outline-none font-medium"
          />
          <kbd className="text-[10px] font-mono px-2 py-0.5 rounded-full border border-[#D9D0C0] bg-white text-[#777777] shrink-0 font-bold">
            ESC
          </kbd>
        </div>

        <div className="flex-1 overflow-y-auto divide-y divide-[#EBE5D8] p-2">
          {results.length === 0 ? (
            <div className="p-8 text-center text-xs text-[#888888]">
              Илэрц олдсонгүй: "{query}"
            </div>
          ) : (
            results.map(node => {
              const p = pathOf(node);
              return (
                <button
                  key={node.i}
                  onClick={() => handleSelect(node)}
                  className="w-full text-left p-3.5 hover:bg-white rounded-2xl cursor-pointer transition flex items-center justify-between group"
                >
                  <div>
                    <div className="text-sm font-bold text-[#141414] group-hover:text-[#D81B60]">
                      {node.t}
                    </div>
                    <div className="text-xs font-mono text-[#777777] mt-0.5">
                      {node.e && <span>{node.e} </span>}
                      {p && <span className="text-[#999999]">• {p}</span>}
                    </div>
                  </div>
                  <CornerDownLeft className="w-3.5 h-3.5 text-[#888888] group-hover:text-[#141414] transition" />
                </button>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
