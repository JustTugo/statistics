import React from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Download, Smartphone, X, CheckCircle2, Share, PlusSquare, ArrowRight } from 'lucide-react';

interface PWAInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  theme?: 'light' | 'dark';
}

export const PWAInstallModal: React.FC<PWAInstallModalProps> = ({
  isOpen,
  onClose,
  theme = 'light'
}) => {
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();
  const isDark = theme === 'dark';

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    const success = await install();
    if (success) {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs select-none animate-in fade-in duration-200">
      <div
        style={{
          backgroundColor: isDark ? '#1C1C1C' : '#FAF7F0',
          borderColor: isDark ? '#333333' : '#E8E2D5',
          color: isDark ? '#EDEDED' : '#141414'
        }}
        className="w-full max-w-md rounded-[28px] border p-6 shadow-2xl relative overflow-hidden"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full text-[#888888] hover:text-white hover:bg-white/10 transition cursor-pointer"
          aria-label="Хаах"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Icon & Title */}
        <div className="flex items-center space-x-3.5 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-[#141414] border border-[#333333] flex items-center justify-center p-1.5 shadow-sm">
            <img src="/icon.svg" alt="App Icon" className="w-full h-full object-contain" />
          </div>
          <div>
            <h3 className="font-extrabold text-base sm:text-lg tracking-tight">
              Android & Утсанд татах
            </h3>
            <p className="text-xs text-[#888888] font-mono">
              JustTugo's Statistic
            </p>
          </div>
        </div>

        {isInstalled ? (
          <div className="p-4 rounded-2xl bg-green-500/10 border border-green-500/30 text-green-500 text-xs flex items-center space-x-2 my-4">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>Аппликейшн таны төхөөрөмж дээр амжилттай суусан байна!</span>
          </div>
        ) : isInstallable ? (
          <div className="space-y-4 my-4">
            <p className="text-xs text-[#666666] dark:text-[#AAAAAA] leading-relaxed">
              Та энэхүү веб хуудсыг Android утсан дээрээ албан ёсны бие даасан апп болгон шууд татан суулгаж, интернетгүй үед ч ашиглах боломжтой.
            </p>

            <button
              onClick={handleInstallClick}
              className="w-full py-3 px-4 rounded-xl bg-[#FF6B8B] hover:bg-[#FF4B72] text-white font-bold text-xs sm:text-sm transition cursor-pointer flex items-center justify-center space-x-2 shadow-md"
            >
              <Download className="w-4 h-4 stroke-[2.5]" />
              <span>Утсанд суулгах (Install App)</span>
            </button>
          </div>
        ) : (
          <div className="space-y-3.5 my-3 text-xs">
            <p className="text-[#666666] dark:text-[#AAAAAA] leading-relaxed">
              Android утсан дээр Chrome хөтчөөс 2 алхмаар шууд татан суулгах:
            </p>

            {/* Android Guide */}
            <div
              style={{
                backgroundColor: isDark ? '#242424' : '#FFFFFF',
                borderColor: isDark ? '#383838' : '#E8E2D5'
              }}
              className="p-3.5 rounded-2xl border space-y-2 text-xs"
            >
              <div className="flex items-center space-x-2 font-bold text-[#FF6B8B]">
                <Smartphone className="w-4 h-4" />
                <span>Android Chrome дээр:</span>
              </div>
              <ol className="list-decimal list-inside space-y-1.5 text-[#555555] dark:text-[#BBBBBB] pl-1 leading-relaxed">
                <li>
                  Chrome хөтчийн баруун дээд буланд байрлах <b>3 цэг (⋮)</b> цэсийг дарна.
                </li>
                <li>
                  Цэснээс <b>"Апп суулгах"</b> эсвэл <b>"Нүүр дэлгэцэнд нэмэх" (Install app / Add to Home screen)</b> сонголтыг сонгоно.
                </li>
                <li>
                  Баталгаажуулах товчийг дарснаар таны утасны дэлгэцэнд бие даасан апп болон татагдана.
                </li>
              </ol>
            </div>

            {/* iOS Guide */}
            <div
              style={{
                backgroundColor: isDark ? '#242424' : '#FFFFFF',
                borderColor: isDark ? '#383838' : '#E8E2D5'
              }}
              className="p-3.5 rounded-2xl border space-y-2 text-xs"
            >
              <div className="flex items-center space-x-2 font-bold text-[#64B5F6]">
                <Share className="w-3.5 h-3.5" />
                <span>iPhone / iPad (Safari) дээр:</span>
              </div>
              <p className="text-[#555555] dark:text-[#BBBBBB] leading-relaxed pl-1">
                Safari хөтчийн <b>Хуваалцах (Share <Share className="w-3 h-3 inline" />)</b> товчийг дарж, доош гүйлгээд <b>"Нүүр дэлгэцэнд нэмэх" (Add to Home Screen)</b> дарна.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
