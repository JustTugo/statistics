import React, { useState } from 'react';
import { X, ArrowRight, CheckCircle, HelpCircle } from 'lucide-react';
import { GraphNode } from '../types';

interface DecisionMatrixModalProps {
  isOpen: boolean;
  onClose: () => void;
  nodesMap: Record<string, GraphNode>;
  onSelectNode: (node: GraphNode) => void;
}

export const DecisionMatrixModal: React.FC<DecisionMatrixModalProps> = ({
  isOpen,
  onClose,
  nodesMap,
  onSelectNode
}) => {
  const [step1, setStep1] = useState<'diff' | 'corr' | null>('diff');
  const [step2, setStep2] = useState<'scale' | 'ordinal' | 'nominal' | null>('scale');
  const [step3, setStep3] = useState<'one_pop' | 'two_ind' | 'two_rel' | 'three_ind' | 'three_rel' | null>('two_ind');
  const [step4, setStep4] = useState<'normal' | 'non_normal' | null>('normal');

  if (!isOpen) return null;

  // Determine recommendation
  let recommendedNodeId: string | null = null;
  let title = '';
  let desc = '';
  let assumption = '';

  if (step1 === 'corr') {
    if (step2 === 'nominal') {
      title = 'Хоёр хүчин зүйлийн Хи-квадрат (Chi-Square Test of Independence)';
      desc = 'Хоёр чанарын/нэрлэсэн хувьсагч хоорондоо хамааралтай эсэхийг шалгана.';
      assumption = 'fe ≥ 5 нүд бүрт, Crosstabs, Phi (2x2) эсвэл Cramer V.';
      recommendedNodeId = 'b6_6';
    } else if (step2 === 'ordinal' || step4 === 'non_normal') {
      title = 'Спирмений эрэмбийн корреляци (Spearman\'s rho)';
      desc = 'Эрэмбийн хувьсагч эсвэл хэвийн бус тоон өгөгдлийн хоорондох хамаарлын хүчийг тодорхойлно.';
      assumption = 'Монотон хамааралтай байх, эрэмбийн нийлбэрт суурилна.';
      recommendedNodeId = 'b7_3';
    } else {
      title = 'Пирсоны шугаман корреляци (Pearson r)';
      desc = 'Хоёр scale хэмжигдэхүүнтэй, хэвийн тархалттай өгөгдлийн шугаман хамаарлын хүч ба чиглэлийг шалгана.';
      assumption = 'Шугаман scatter plot, хэвийн тархалт, хэт утгагүй байх.';
      recommendedNodeId = 'b7_2';
    }
  } else if (step1 === 'diff') {
    if (step2 === 'nominal') {
      title = 'Нэг хүчин зүйлийн Хи-квадрат (Chi-Square Goodness-of-Fit)';
      desc = 'Нэг нэрлэсэн хувьсагчийн бодит давтамж онолын хүлээгдэх давтамжтай тохирч буй эсэхийг шалгана.';
      assumption = 'Нүд бүрийн fe ≥ 5, ажиглалтын тоо хангалттай байх.';
      recommendedNodeId = 'b6_5';
    } else if (step3 === 'one_pop') {
      title = 'Нэг түүврийн t-шинжилгээ (One-Sample t-Test)';
      desc = 'Судалж буй 1 түүврийн дунджийг эх олонлогийн тогтсон норм стандарт дундажтай харьцуулна.';
      assumption = 'Scale хувьсагч, N ≥ 30, хэвийн тархалттай.';
      recommendedNodeId = 'b4_2';
    } else if (step3 === 'two_ind') {
      if (step4 === 'non_normal' || step2 === 'ordinal') {
        title = 'Манн-Уитни U тест (Mann–Whitney U Test)';
        desc = 'Түүвэр цөөн (N < 30) эсвэл тархалт хэвийн бус үед 2 бие даасан бүлгийн эрэмбийн нийлбэрийг харьцуулна.';
        assumption = 'Параметрийн бус шалгуур, 2 бие даасан бүлэг.';
        recommendedNodeId = 'b6_1';
      } else {
        title = 'Хараат бус 2 түүврийн t-тест (Independent-Samples t-Test)';
        desc = 'Хоёр бие даасан бүлгийн (ж: туршилтын vs хяналтын) дунджийг харьцуулах параметрик арга.';
        assumption = 'Тархалт хэвийн, Levene дисперсийн шалгуур p > .05 байх.';
        recommendedNodeId = 'b4_3';
      }
    } else if (step3 === 'two_rel') {
      if (step4 === 'non_normal' || step2 === 'ordinal') {
        title = 'Уилкоксоны тэмдэгт эрэмбийн шалгуур (Wilcoxon Signed-Rank Test)';
        desc = 'Нэг оролцогчийн өмнөх ба дараах 2 хэмжилтийн параметрийн бус хувилбар.';
        assumption = 'Хосолсон хэмжилтүүд, зөрүүний чиглэл ба эрэмбэ.';
        recommendedNodeId = 'b6_2';
      } else {
        title = 'Хосолсон түүврийн t-тест (Paired-Samples t-Test)';
        desc = 'Нэг оролцогчийн өмнөх ба дараах (Pre-Post) хоёр хэмжилтийн дунджийн зөрүүг шалгана.';
        assumption = 'Зөрүүний оноонууд (D) хэвийн тархалттай байх.';
        recommendedNodeId = 'b4_4';
      }
    } else if (step3 === 'three_ind') {
      if (step4 === 'non_normal' || step2 === 'ordinal') {
        title = 'Крускал-Уоллис H шалгуур (Kruskal–Wallis H Test)';
        desc = '3 ба түүнээс дээш бие даасан бүлгийн дунджийг эрэмбээр шалгах параметрийн бус арга.';
        assumption = '3+ бие даасан бүлэг, медианы харьцуулалт.';
        recommendedNodeId = 'b6_3';
      } else {
        title = 'Нэг хүчин зүйлийн Дисперсийн шинжилгээ (One-Way ANOVA)';
        desc = '3 ба түүнээс дээш бие даасан бүлгийн дунджийг харьцуулах F-тест.';
        assumption = 'Дисперс тэнцүү (Levene p > .05), бүлэг тус бүр n ≥ 15, Post-Hoc (Tukey/LSD).';
        recommendedNodeId = 'b5_1';
      }
    } else if (step3 === 'three_rel') {
      if (step4 === 'non_normal' || step2 === 'ordinal') {
        title = 'Фридманы хоёр хүчин зүйлийн ANOVA (Friedman Test)';
        desc = '3 ба түүнээс дээш давтан хэмжилтийн параметрийн бус хувилбар.';
        assumption = '3+ давтан хэмжилттэй жижиг түүвэр (N ≥ 5) эсвэл эрэмбийн үнэлгээ.';
        recommendedNodeId = 'b6_4';
      } else {
        title = 'Давтан хэмжилтийн ANOVA (Repeated-Measures ANOVA)';
        desc = 'Нэг түүврээс 3 ба түүнээс дээш цагийн цэгт хэмжсэн өгөгдлийг шалгана.';
        assumption = 'Mauchly\'s test of sphericity (p > .05), үгүй бол Greenhouse-Geisser залруулга.';
        recommendedNodeId = 'b5_5';
      }
    }
  }

  const handleOpenNode = () => {
    if (recommendedNodeId && nodesMap[recommendedNodeId]) {
      onSelectNode(nodesMap[recommendedNodeId]);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs p-4 sm:p-8 overflow-y-auto flex items-start justify-center select-none">
      <div className="w-full max-w-5xl bg-[#1E1E1E] border border-[#333333] rounded-[28px] shadow-2xl p-6 sm:p-8 my-8 relative text-[#F2F2F2]">
        {/* Header */}
        <div className="flex items-start justify-between pb-6 border-b border-[#383838]">
          <div>
            <div className="flex items-center space-x-2 text-xs font-mono text-[#858585] uppercase tracking-wider mb-1">
              <span>СТАТИСТИКИЙН ШИНЖИЛГЭЭ СОНГОХ СХЕМ</span>
            </div>
            <h2 className="text-2xl font-bold tracking-tight text-[#F2F2F2]">
              Зохистой статистик шинжилгээг сонгох схем
            </h2>
            <p className="text-xs text-[#B0B0B0] mt-1.5 max-w-2xl leading-relaxed">
              Судалгааны асуулт, хэмжилтийн түвшин (NOIR), бүлгийн бүтэц болон өгөгдлийн тархалтын хэлбэрээс
              хамаарч зөв шинжилгээний тестийг алдаагүй тодорхойлох ухаалаг схем.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-[#292929] text-[#858585] hover:text-white transition cursor-pointer"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* 4-Step Interactive Decision Wizard */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-4 gap-4">
          {/* Step 1 */}
          <div className="bg-[#292929] border border-[#383838] rounded-xl p-4">
            <div className="text-[10px] font-mono text-[#858585]">АЛХАМ 01</div>
            <div className="font-semibold text-[#F2F2F2] text-sm mt-1">Судалгааны асуулт</div>
            <p className="text-xs text-[#B0B0B0] mt-1">Ялгаа харьцуулах уу эсвэл хамаарал холбоо судлах уу?</p>
            <div className="mt-4 space-y-2">
              <button
                onClick={() => setStep1('diff')}
                className={`w-full text-left px-3 py-2 rounded-lg text-xs font-medium border transition cursor-pointer ${
                  step1 === 'diff'
                    ? 'border-white bg-[#383838] text-white shadow-sm'
                    : 'border-[#383838] bg-[#202020] text-[#B0B0B0] hover:border-[#858585]'
                }`}
              >
                Бүлгүүдийн ялгаа үзэх
              </button>
              <button
                onClick={() => setStep1('corr')}
                className={`w-full text-left px-3 py-2 rounded-lg text-xs font-medium border transition cursor-pointer ${
                  step1 === 'corr'
                    ? 'border-white bg-[#383838] text-white shadow-sm'
                    : 'border-[#383838] bg-[#202020] text-[#B0B0B0] hover:border-[#858585]'
                }`}
              >
                Хувьсагчдын хамаарал үзэх
              </button>
            </div>
          </div>

          {/* Step 2 */}
          <div className="bg-[#292929] border border-[#383838] rounded-xl p-4">
            <div className="text-[10px] font-mono text-[#858585]">АЛХАМ 02</div>
            <div className="font-semibold text-[#F2F2F2] text-sm mt-1">Хэмжилтийн түвшин</div>
            <p className="text-xs text-[#B0B0B0] mt-1">Хамаарах хувьсагчийн масштаб ямар төрөл вэ?</p>
            <div className="mt-4 space-y-2">
              <button
                onClick={() => setStep2('scale')}
                className={`w-full text-left px-3 py-2 rounded-lg text-xs font-medium border transition cursor-pointer ${
                  step2 === 'scale'
                    ? 'border-white bg-[#383838] text-white shadow-sm'
                    : 'border-[#383838] bg-[#202020] text-[#B0B0B0] hover:border-[#858585]'
                }`}
              >
                Интервал / Харьцаа (Scale)
              </button>
              <button
                onClick={() => setStep2('ordinal')}
                className={`w-full text-left px-3 py-2 rounded-lg text-xs font-medium border transition cursor-pointer ${
                  step2 === 'ordinal'
                    ? 'border-white bg-[#383838] text-white shadow-sm'
                    : 'border-[#383838] bg-[#202020] text-[#B0B0B0] hover:border-[#858585]'
                }`}
              >
                Эрэмбийн (Ordinal)
              </button>
              <button
                onClick={() => setStep2('nominal')}
                className={`w-full text-left px-3 py-2 rounded-lg text-xs font-medium border transition cursor-pointer ${
                  step2 === 'nominal'
                    ? 'border-white bg-[#383838] text-white shadow-sm'
                    : 'border-[#383838] bg-[#202020] text-[#B0B0B0] hover:border-[#858585]'
                }`}
              >
                Нэрлэсэн (Nominal/Давтамж)
              </button>
            </div>
          </div>

          {/* Step 3 */}
          <div className="bg-[#292929] border border-[#383838] rounded-xl p-4">
            <div className="text-[10px] font-mono text-[#858585]">АЛХАМ 03</div>
            <div className="font-semibold text-[#F2F2F2] text-sm mt-1">Бүлгийн бүтэц</div>
            <p className="text-xs text-[#B0B0B0] mt-1">Хэдэн бүлэг, хамааралтай эсэх?</p>
            <div className="mt-4 space-y-2">
              <button
                onClick={() => setStep3('one_pop')}
                className={`w-full text-left px-3 py-1.5 rounded-lg text-xs font-medium border transition cursor-pointer ${
                  step3 === 'one_pop'
                    ? 'border-white bg-[#383838] text-white shadow-sm'
                    : 'border-[#383838] bg-[#202020] text-[#B0B0B0] hover:border-[#858585]'
                }`}
              >
                1 бүлэг vs Стандарт норм
              </button>
              <button
                onClick={() => setStep3('two_ind')}
                className={`w-full text-left px-3 py-1.5 rounded-lg text-xs font-medium border transition cursor-pointer ${
                  step3 === 'two_ind'
                    ? 'border-white bg-[#383838] text-white shadow-sm'
                    : 'border-[#383838] bg-[#202020] text-[#B0B0B0] hover:border-[#858585]'
                }`}
              >
                2 бие даасан бүлэг
              </button>
              <button
                onClick={() => setStep3('two_rel')}
                className={`w-full text-left px-3 py-1.5 rounded-lg text-xs font-medium border transition cursor-pointer ${
                  step3 === 'two_rel'
                    ? 'border-white bg-[#383838] text-white shadow-sm'
                    : 'border-[#383838] bg-[#202020] text-[#B0B0B0] hover:border-[#858585]'
                }`}
              >
                2 хосолсон (Өмнөх/Дараах)
              </button>
              <button
                onClick={() => setStep3('three_ind')}
                className={`w-full text-left px-3 py-1.5 rounded-lg text-xs font-medium border transition cursor-pointer ${
                  step3 === 'three_ind'
                    ? 'border-white bg-[#383838] text-white shadow-sm'
                    : 'border-[#383838] bg-[#202020] text-[#B0B0B0] hover:border-[#858585]'
                }`}
              >
                3+ бие даасан бүлэг
              </button>
              <button
                onClick={() => setStep3('three_rel')}
                className={`w-full text-left px-3 py-1.5 rounded-lg text-xs font-medium border transition cursor-pointer ${
                  step3 === 'three_rel'
                    ? 'border-white bg-[#383838] text-white shadow-sm'
                    : 'border-[#383838] bg-[#202020] text-[#B0B0B0] hover:border-[#858585]'
                }`}
              >
                3+ давтан (Repeated)
              </button>
            </div>
          </div>

          {/* Step 4 */}
          <div className="bg-[#292929] border border-[#383838] rounded-xl p-4">
            <div className="text-[10px] font-mono text-[#858585]">АЛХАМ 04</div>
            <div className="font-semibold text-[#F2F2F2] text-sm mt-1">Нөхцөл & Тархалт</div>
            <p className="text-xs text-[#B0B0B0] mt-1">Шалгуур (S-W, K-S, p &gt; .05, Дисперс)?</p>
            <div className="mt-4 space-y-2">
              <button
                onClick={() => setStep4('normal')}
                className={`w-full text-left px-3 py-2 rounded-lg text-xs font-medium border transition cursor-pointer ${
                  step4 === 'normal'
                    ? 'border-white bg-[#383838] text-white shadow-sm'
                    : 'border-[#383838] bg-[#202020] text-[#B0B0B0] hover:border-[#858585]'
                }`}
              >
                Хэвийн тархалттай (Параметрик)
              </button>
              <button
                onClick={() => setStep4('non_normal')}
                className={`w-full text-left px-3 py-2 rounded-lg text-xs font-medium border transition cursor-pointer ${
                  step4 === 'non_normal'
                    ? 'border-white bg-[#383838] text-white shadow-sm'
                    : 'border-[#383838] bg-[#202020] text-[#B0B0B0] hover:border-[#858585]'
                }`}
              >
                Хэвийн бус / N &lt; 30 (Параметрийн бус)
              </button>
            </div>
          </div>
        </div>

        {/* Result Recommendation Card */}
        <div className="mt-8 p-6 rounded-2xl border border-emerald-800/80 bg-emerald-950/20">
          <div className="text-xs font-mono text-emerald-400 flex items-center space-x-1.5 uppercase tracking-wider">
            <CheckCircle className="w-4 h-4" />
            <span>ЗӨВЛӨЖ БУЙ ШИНЖИЛГЭЭНИЙ ТЕСТ:</span>
          </div>
          <div className="text-xl sm:text-2xl font-bold text-[#F2F2F2] mt-2">
            {title || 'Дээрх алхмуудаас тохиргоогоо сонгоно уу'}
          </div>
          <p className="text-sm text-[#B0B0B0] mt-2 leading-relaxed">{desc}</p>
          {assumption && (
            <div className="mt-2 text-xs font-mono text-[#858585] flex items-center space-x-1.5">
              <HelpCircle className="w-3.5 h-3.5 text-emerald-400" />
              <span>Тавигдах үндсэн шаардлага: {assumption}</span>
            </div>
          )}

          {recommendedNodeId && (
            <div className="mt-5">
              <button
                onClick={handleOpenNode}
                className="px-5 py-2.5 rounded-xl bg-white text-[#151515] font-semibold text-xs hover:bg-[#E5E5E5] transition flex items-center space-x-2 cursor-pointer shadow-lg"
              >
                <span>Энэ сэдвийг оюуны зураглал дээр үзэх</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>

        {/* Reference Table */}
        <div className="mt-10">
          <h3 className="text-sm font-bold text-[#F2F2F2] uppercase tracking-wider mb-3">
            Лекц 5, 8, 9, 10, 11, 12-ийн харьцуулсан лавлах хүснэгт
          </h3>
          <div className="border border-[#383838] rounded-xl overflow-x-auto bg-[#151515]">
            <table className="w-full text-left text-xs text-[#B0B0B0]">
              <thead className="bg-[#292929] border-b border-[#383838] text-[#F2F2F2] font-mono uppercase text-[11px]">
                <tr>
                  <th className="p-3.5">Судалгааны асуулт</th>
                  <th className="p-3.5">Параметрик тест</th>
                  <th className="p-3.5">Параметрийн бус тест</th>
                  <th className="p-3.5">Тавигдах үндсэн шаардлага</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#2a2a2a] font-mono text-[11.5px]">
                <tr className="hover:bg-[#202020]/50 transition">
                  <td className="p-3.5 text-[#F2F2F2]">1 бүлэг vs Стандарт норм</td>
                  <td className="p-3.5 text-[#F2F2F2] font-semibold">One-sample t-test</td>
                  <td className="p-3.5 text-[#858585]">Wilcoxon signed-rank (1-sample)</td>
                  <td className="p-3.5">Scale, n ≥ 30, хэвийн тархалт</td>
                </tr>
                <tr className="hover:bg-[#202020]/50 transition">
                  <td className="p-3.5 text-[#F2F2F2]">2 бие даасан бүлэг</td>
                  <td className="p-3.5 text-[#F2F2F2] font-semibold">Independent-samples t-test</td>
                  <td className="p-3.5 text-[#F2F2F2] font-semibold">Mann–Whitney U</td>
                  <td className="p-3.5">Тархалт хэвийн, Levene дисперс тэнцүү (p &gt; .05)</td>
                </tr>
                <tr className="hover:bg-[#202020]/50 transition">
                  <td className="p-3.5 text-[#F2F2F2]">2 хамааралтай хэмжилт</td>
                  <td className="p-3.5 text-[#F2F2F2] font-semibold">Paired-samples t-test</td>
                  <td className="p-3.5 text-[#F2F2F2] font-semibold">Wilcoxon signed-rank</td>
                  <td className="p-3.5">Давтан хэмжих, зөрүү нь хэвийн тархалттай</td>
                </tr>
                <tr className="hover:bg-[#202020]/50 transition">
                  <td className="p-3.5 text-[#F2F2F2]">3+ бие даасан бүлэг</td>
                  <td className="p-3.5 text-[#F2F2F2] font-semibold">One-way ANOVA</td>
                  <td className="p-3.5 text-[#F2F2F2] font-semibold">Kruskal–Wallis H</td>
                  <td className="p-3.5">Дисперс тэнцүү, бүлгийн тоо ойролцоо, Post-Hoc: Tukey/LSD</td>
                </tr>
                <tr className="hover:bg-[#202020]/50 transition">
                  <td className="p-3.5 text-[#F2F2F2]">3+ хамааралтай хэмжилт</td>
                  <td className="p-3.5 text-[#F2F2F2] font-semibold">Repeated-measures ANOVA</td>
                  <td className="p-3.5 text-[#F2F2F2] font-semibold">Friedman's test</td>
                  <td className="p-3.5">Mauchly's sphericity (p &gt; .05), үгүй бол Greenhouse-Geisser</td>
                </tr>
                <tr className="hover:bg-[#202020]/50 transition">
                  <td className="p-3.5 text-[#F2F2F2]">2 тоон хувьсагчийн хамаарал</td>
                  <td className="p-3.5 text-[#F2F2F2] font-semibold">Pearson r</td>
                  <td className="p-3.5 text-[#F2F2F2] font-semibold">Spearman ρ / Kendall τ</td>
                  <td className="p-3.5">Шугаман scatter plot, хэвийн тархалт</td>
                </tr>
                <tr className="hover:bg-[#202020]/50 transition">
                  <td className="p-3.5 text-[#F2F2F2]">Ангиллын (Чанарын) хувьсагчид</td>
                  <td className="p-3.5 text-[#858585]">—</td>
                  <td className="p-3.5 text-[#F2F2F2] font-semibold">χ² (Хи-квадрат)</td>
                  <td className="p-3.5">Нүд бүрийн fe ≥ 5, ажиглалтын тоо N хангалттай</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
