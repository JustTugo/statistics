import React, { useState } from 'react';
import { GraphNode } from '../types';
import { MathFormula } from './MathFormula';
import {
  Sparkles,
  ArrowRight,
  Calculator,
  GitFork,
  Network,
  Brain,
  ChevronRight
} from 'lucide-react';

interface IntellyDashboardProps {
  nodesMap: Record<string, GraphNode>;
  nodesList: GraphNode[];
  branches: GraphNode[];
  onSelectNode: (node: GraphNode) => void;
  onOpenMindMap: () => void;
  onOpenMatrix: () => void;
  onOpenCalculator: () => void;
  onOpenBookmarks: () => void;
  theme?: 'light' | 'dark';
}

export const IntellyDashboard: React.FC<IntellyDashboardProps> = ({
  nodesMap,
  branches,
  onSelectNode,
  onOpenMindMap,
  onOpenMatrix,
  onOpenCalculator,
  theme = 'light'
}) => {
  const isDark = theme === 'dark';

  // Currently highlighted topic in the lower detail card
  const [selectedTopicId, setSelectedTopicId] = useState<string>('b4_3');
  const activeTopic = nodesMap[selectedTopicId] || nodesMap['b4_3'] || nodesMap['b5_1'] || nodesMap['stat'];

  const filteredTopics = [
    {
      id: 'b4_3',
      node: nodesMap['b4_3'],
      time: '09:15 AM',
      bgColor: 'bg-[#FAD5E3]',
      iconColor: 'text-[#D81B60]',
      title: 'Хоёр бие даасан түүврийн Т-тест',
      category: 'Independent-Samples t-test',
      branch: 'Бүлгүүдийн ялгаа'
    },
    {
      id: 'b5_1',
      node: nodesMap['b5_1'],
      time: '10:30 AM',
      bgColor: 'bg-[#C8E6F5]',
      iconColor: 'text-[#0288D1]',
      title: 'Нэг хүчин зүйлийн ANOVA',
      category: 'One-Way ANOVA (F-test)',
      branch: 'Дисперсийн шинжилгээ'
    },
    {
      id: 'b7_2',
      node: nodesMap['b7_2'],
      time: '11:45 AM',
      bgColor: 'bg-[#EBD5F5]',
      iconColor: 'text-[#8E24AA]',
      title: 'Пирсоны r корреляци',
      category: 'Pearson r correlation',
      branch: 'Хамаарал ба регресс'
    },
    {
      id: 'b6_1',
      node: nodesMap['b6_1'],
      time: '02:00 PM',
      bgColor: 'bg-[#DDF0CC]',
      iconColor: 'text-[#558B2F]',
      title: 'Манн–Уитни U шалгуур',
      category: 'Mann–Whitney U (Rank Sums)',
      branch: 'Непараметрийн шалгуур'
    },
    {
      id: 'b7_4',
      node: nodesMap['b7_4'],
      time: '03:30 PM',
      bgColor: 'bg-[#FFE0B2]',
      iconColor: 'text-[#F57C00]',
      title: 'Шугаман регрессийн шинжилгээ',
      category: 'Linear Regression (R²)',
      branch: 'Хамаарал ба регресс'
    },
    {
      id: 'b8_1',
      node: nodesMap['b8_1'],
      time: '04:15 PM',
      bgColor: 'bg-[#FBE7C6]',
      iconColor: 'text-[#B45309]',
      title: 'Найдвартай байдал (Кронбахын альфа)',
      category: 'Cronbach’s Alpha (α ≥ 0.70)',
      branch: 'Сэтгэц хэмжил зүй'
    },
    {
      id: 'b6_6',
      node: nodesMap['b6_6'],
      time: '05:00 PM',
      bgColor: 'bg-[#E0D4C5]',
      iconColor: 'text-[#5D4037]',
      title: 'Хоёр хүчин зүйлийн Хи-квадрат',
      category: 'Test of Independence (2×2, φ, V)',
      branch: 'Давтамжийн шинжилгээ'
    }
  ];

  return (
    <div
      style={{
        backgroundColor: isDark ? '#161616' : '#FAF7F0',
        color: isDark ? '#F5F5F5' : '#141414'
      }}
      className="absolute inset-0 overflow-y-auto px-4 sm:px-10 py-6 sm:py-7 space-y-7 transition-colors duration-300 overscroll-contain"
    >
      {/* 1. Welcoming Hero Title: Greeting updated to "Сайн байна уу!" (Without JustTugo) */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight font-sans">
            Сайн байна уу!
          </h1>
          <p
            style={{ color: isDark ? '#A0A0A0' : '#6B6B6B' }}
            className="text-xs sm:text-sm mt-1.5 max-w-2xl font-normal leading-relaxed"
          >
            Сэтгэл судлалын статистикийн судалгааны аргуудыг цогцоор нь эзэмших интерактив оюуны зураглал. 9 үндсэн салбар, 60+ нарийвчилсан ухагдахуун.
            <span className="font-mono text-[11px] block mt-1 text-[#FF6B8B] font-semibold">
              Хөгжүүлсэн: By JustTugo
            </span>
          </p>
        </div>

        <button
          onClick={onOpenMindMap}
          className="text-xs font-bold text-[#FF6B8B] hover:opacity-80 transition cursor-pointer flex items-center space-x-1 shrink-0 group underline decoration-dotted"
        >
          <span>JustTugo's Statistic нээх ...</span>
          <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition" />
        </button>
      </div>

      {/* 2. Pastel Bento Grid: 4 Signature Cards matching screenshot */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* CARD 1: Warm Yellow (Measurements & Variables) */}
        <div className="bg-[#FAD968] rounded-[24px] p-5 relative overflow-hidden flex flex-col justify-between shadow-sm min-h-[195px] border border-[#F0CA4E]/40 group hover:shadow-md transition">
          <div className="absolute -top-3 -right-3 w-20 h-20 opacity-30 pointer-events-none">
            <svg viewBox="0 0 100 100" fill="none">
              <path d="M35 15H65V35H85V65H65V85H35V65H15V35H35V15Z" fill="#D4A017" />
            </svg>
          </div>

          <div>
            <h3 className="font-bold text-[#1F1F1F] text-sm tracking-tight">
              Хэмжилт & Өгөгдөл:
            </h3>
            <div className="flex items-center gap-4 mt-2.5">
              <div>
                <span className="text-xs font-bold text-[#1F1F1F] block">60+ сэдэв</span>
                <span className="text-[10px] text-[#443810] font-mono">НИЙТ</span>
              </div>
              <div>
                <span className="text-xs font-bold text-[#1F1F1F] block">9 салбар</span>
                <span className="text-[10px] text-[#443810] font-mono">САЛБАР</span>
              </div>
              <div>
                <span className="text-xs font-bold text-[#1F1F1F] block">4 түвшин</span>
                <span className="text-[10px] text-[#443810] font-mono">NOIR</span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-[#E5C250]/40">
            <div className="flex items-end justify-between h-14 gap-1.5 px-1">
              <div className="flex-1 bg-[#D9A726] rounded-t-sm h-[35%]" title="Nominal" />
              <div className="flex-1 bg-[#D9A726] rounded-t-sm h-[55%]" title="Ordinal" />
              <div className="flex-1 bg-[#D9A726] rounded-t-sm h-[70%]" title="Interval" />
              <div className="flex-1 bg-[#1A1A1A] rounded-t-sm h-[95%]" title="Ratio" />
              <div className="flex-1 bg-[#D9A726] rounded-t-sm h-[45%]" />
              <div className="flex-1 bg-[#D9A726] rounded-t-sm h-[60%]" />
              <div className="flex-1 bg-[#D9A726] rounded-t-sm h-[30%]" />
            </div>
            <div className="flex justify-between text-[9px] font-mono text-[#544415] mt-1.5 px-1">
              <span>Чанарын</span>
              <span>Тоон өгөгдөл</span>
            </div>
          </div>
        </div>

        {/* CARD 2: Soft Strawberry Pink (Normal Curve & z-Score) */}
        <div className="bg-[#F7BED4] rounded-[24px] p-5 relative overflow-hidden flex flex-col justify-between shadow-sm min-h-[195px] border border-[#F2A5C3]/40 group hover:shadow-md transition">
          <div className="absolute -top-2 -right-2 w-20 h-20 opacity-25 pointer-events-none">
            <svg viewBox="0 0 100 100" fill="#C2185B">
              <path d="M50 82L44 76.5C21 55.7 6 42 6 25C6 11 17 0 31 0C39 0 46.5 3.7 50 9.5C53.5 3.7 61 0 69 0C83 0 94 11 94 25C94 42 79 55.7 56 76.5L50 82Z" />
            </svg>
          </div>

          <div>
            <h3 className="font-bold text-[#1F1F1F] text-sm tracking-tight">
              Хэвийн тархалт & z:
            </h3>
            <div className="flex items-center gap-4 mt-2.5">
              <div>
                <span className="text-xs font-bold text-[#1F1F1F] block">μ = 0</span>
                <span className="text-[10px] text-[#631835] font-mono">ДУНДАЖ</span>
              </div>
              <div>
                <span className="text-xs font-bold text-[#1F1F1F] block">σ = 1</span>
                <span className="text-[10px] text-[#631835] font-mono">ХАЗАЙЛТ</span>
              </div>
              <div>
                <span className="text-xs font-bold text-[#1F1F1F] block">p &lt; .05</span>
                <span className="text-[10px] text-[#631835] font-mono">БОСГО</span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-[#F2A5C3]/40">
            <div className="relative h-14 w-full">
              <svg viewBox="0 0 200 60" className="w-full h-full overflow-visible">
                <path
                  d="M 5 55 Q 50 52 80 35 Q 100 8 100 8 Q 100 8 120 35 Q 150 52 195 55"
                  fill="none"
                  stroke="#701235"
                  strokeWidth="2.5"
                />
                <line x1="100" y1="8" x2="100" y2="55" stroke="#701235" strokeDasharray="3 3" strokeWidth="1.2" />
                <circle cx="100" cy="8" r="4" fill="#141414" stroke="#ffffff" strokeWidth="1.5" />
              </svg>
            </div>
            <div className="flex justify-between text-[9px] font-mono text-[#7A1F44] mt-1 px-1">
              <span>-3σ</span>
              <span className="font-bold">z = 0</span>
              <span>+3σ</span>
            </div>
          </div>
        </div>

        {/* CARD 3: Avocado / Sage Green (Hypothesis Decisions) */}
        <div className="bg-[#A8C57C] rounded-[24px] p-5 relative overflow-hidden flex flex-col justify-between shadow-sm min-h-[195px] border border-[#96B867]/40 group hover:shadow-md transition">
          <div className="absolute -top-3 -right-3 w-20 h-20 opacity-25 pointer-events-none">
            <svg viewBox="0 0 100 100" fill="#33691E">
              <polygon points="50,15 90,85 10,85" />
            </svg>
          </div>

          <div>
            <h3 className="font-bold text-[#1F1F1F] text-sm tracking-tight">
              Таамаглал шалгах:
            </h3>
            <div className="flex items-center gap-4 mt-2.5">
              <div>
                <span className="text-xs font-bold text-[#1F1F1F] block">16 арга</span>
                <span className="text-[10px] text-[#29420F] font-mono">ПАРАМЕТРИК</span>
              </div>
              <div>
                <span className="text-xs font-bold text-[#1F1F1F] block">6 арга</span>
                <span className="text-[10px] text-[#29420F] font-mono">НЕПАРАМЕТРИК</span>
              </div>
              <div>
                <span className="text-xs font-bold text-[#1F1F1F] block">α = .05</span>
                <span className="text-[10px] text-[#29420F] font-mono">АЛДАА I</span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-[#96B867]/40">
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-[11px] font-medium text-[#1E300B]">
                <span>H₀ (Тэг таамаглал):</span>
                <span className="font-mono font-bold text-xs">p &gt; .05</span>
              </div>
              <div className="w-full bg-[#8EAF5F] rounded-full h-2 overflow-hidden">
                <div className="bg-[#1C320A] h-full rounded-full w-[65%]" />
              </div>
              <div className="flex justify-between text-[9px] font-mono text-[#2B4710] mt-1">
                <span>Ялгаагүй</span>
                <span className="font-bold">Ач холбогдолтой</span>
              </div>
            </div>
          </div>
        </div>

        {/* CARD 4: Soft Cornflower Blue (SPSS & Practice) */}
        <div className="bg-[#96BEE9] rounded-[24px] p-5 relative overflow-hidden flex flex-col justify-between shadow-sm min-h-[195px] border border-[#80ABDD]/40 group hover:shadow-md transition">
          <div className="absolute -top-3 -right-3 w-20 h-20 opacity-30 pointer-events-none">
            <svg viewBox="0 0 100 100" fill="#0D47A1">
              <path d="M50 0L58 35L93 20L75 50L100 65L68 75L70 100L45 80L25 95L30 68L0 60L28 42L15 15L45 30Z" />
            </svg>
          </div>

          <div>
            <h3 className="font-bold text-[#1F1F1F] text-sm tracking-tight">
              SPSS Практик багц:
            </h3>
            <div className="flex items-center gap-3.5 mt-2.5">
              <div>
                <span className="text-xs font-bold text-[#1F1F1F] block">.sav</span>
                <span className="text-[10px] text-[#0E2E59] font-mono">ӨГӨГДӨЛ</span>
              </div>
              <div>
                <span className="text-xs font-bold text-[#1F1F1F] block">.spv</span>
                <span className="text-[10px] text-[#0E2E59] font-mono">ҮР ДҮН</span>
              </div>
              <div>
                <span className="text-xs font-bold text-[#1F1F1F] block">.sps</span>
                <span className="text-[10px] text-[#0E2E59] font-mono">СИНТАКС</span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-[#80ABDD]/40 flex items-center justify-between">
            <button
              onClick={onOpenCalculator}
              className="px-3 py-1.5 rounded-full bg-[#141414] text-white text-[11px] font-semibold hover:bg-black transition flex items-center space-x-1 cursor-pointer"
            >
              <Calculator className="w-3 h-3 text-[#96BEE9]" />
              <span>Тооцоолуур</span>
            </button>
            <button
              onClick={onOpenMatrix}
              className="px-3 py-1.5 rounded-full bg-white/75 hover:bg-white text-[#141414] text-[11px] font-semibold transition flex items-center space-x-1 cursor-pointer"
            >
              <GitFork className="w-3 h-3 text-[#141414]" />
              <span>Шийдвэрийн мод</span>
            </button>
          </div>
        </div>
      </div>

      {/* 3. Lower Content: Two Column Layout (Expansive & Balanced) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pt-2">
        {/* Left Column (5.5 Cols): Topics / Tests List */}
        <div className="lg:col-span-5 space-y-3.5">
          <div className="flex items-center justify-between pb-1">
            <h2 className="text-base font-bold tracking-tight">
              Гол шинжилгээний аргууд
            </h2>
          </div>

          <div className="space-y-2.5">
            {filteredTopics.map(item => {
              const isSelected = selectedTopicId === item.id;
              return (
                <div
                  key={item.id}
                  onClick={() => {
                    setSelectedTopicId(item.id);
                  }}
                  style={{
                    backgroundColor: isSelected
                      ? (isDark ? '#222222' : '#FFFFFF')
                      : (isDark ? '#1A1A1A' : '#F2ECE1'),
                    borderColor: isSelected ? (isDark ? '#FF6B8B' : '#141414') : 'transparent'
                  }}
                  className="p-3.5 rounded-[22px] transition cursor-pointer flex items-center justify-between border shadow-2xs hover:scale-[1.01]"
                >
                  <div className="flex items-center space-x-3.5 truncate">
                    <div className={`w-10 h-10 rounded-full ${item.bgColor} flex items-center justify-center shrink-0`}>
                      <Brain className={`w-5 h-5 ${item.iconColor}`} />
                    </div>
                    <div className="truncate">
                      <div className="font-bold text-xs truncate">
                        {item.title}
                      </div>
                      <div
                        style={{ color: isDark ? '#9E9E9E' : '#777777' }}
                        className="text-[10.5px] font-mono truncate"
                      >
                        {item.category}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2 shrink-0">
                    <span
                      style={{
                        backgroundColor: isDark ? '#303030' : '#E8E2D4',
                        color: isDark ? '#E0E0E0' : '#141414'
                      }}
                      className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full"
                    >
                      {item.time}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column (6.5 Cols): Active Topic Details Card (Rose/Blush Card #F8C8DD) */}
        <div className="lg:col-span-7">
          <div className="pb-1">
            <h2 className="text-base font-bold tracking-tight">
              Шинжилгээний дэлгэрэнгүй
            </h2>
          </div>

          <div className="bg-[#F8C8DD] rounded-[26px] p-6 sm:p-7 border border-[#F2B0CC]/60 shadow-sm space-y-4.5 text-[#141414]">
            {/* Header with Title */}
            <div className="flex items-start justify-between gap-3">
              <div>
                <h3 className="font-extrabold text-xl text-[#141414]">
                  {activeTopic.t}
                </h3>
                {activeTopic.e && (
                  <p className="text-xs text-[#631835] font-mono font-medium mt-0.5">
                    {activeTopic.e}
                  </p>
                )}
              </div>
            </div>

            {/* Pill Tags */}
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="px-3 py-0.5 rounded-full bg-[#E580A7]/35 text-[#4D0D27] text-[11px] font-semibold">
                Параметрик арга
              </span>
              <span className="px-3 py-0.5 rounded-full bg-[#E580A7]/35 text-[#4D0D27] text-[11px] font-semibold">
                Scale өгөгдөл
              </span>
              <span className="px-3 py-0.5 rounded-full bg-[#E580A7]/35 text-[#4D0D27] text-[11px] font-semibold">
                {activeTopic.lv === 1 ? 'Үндсэн салбар' : 'Дэд ухагдахуун'}
              </span>
            </div>

            {/* Math Formula */}
            {activeTopic.f && (
              <div className="p-3.5 bg-white/80 rounded-2xl border border-[#F2B0CC]">
                <div className="text-[10px] font-mono text-[#631835] uppercase font-bold mb-1">
                  Математик томьёо:
                </div>
                <div className="overflow-x-auto py-1 text-center">
                  <MathFormula formula={activeTopic.f} displayMode={true} />
                </div>
              </div>
            )}

            {/* Description & Clinical Observation */}
            <div className="text-xs text-[#2A101C] leading-relaxed space-y-2.5">
              <p className="line-clamp-3">
                {activeTopic.d}
              </p>

              {activeTopic.c && (
                <div className="pt-2 border-t border-[#F0A9C6]/60">
                  <span className="font-bold text-[#631835] block text-[11px]">
                    Тавигдах шалгуур (Assumptions):
                  </span>
                  <span className="text-[11px] text-[#331120] block mt-0.5">
                    {activeTopic.c}
                  </span>
                </div>
              )}

              {activeTopic.s && (
                <div className="pt-2 border-t border-[#F0A9C6]/60">
                  <span className="font-bold text-[#631835] block text-[11px]">
                    SPSS дэх алхам:
                  </span>
                  <span className="text-[11px] text-[#331120] font-mono block mt-0.5 bg-white/60 p-2.5 rounded-xl">
                    {activeTopic.s}
                  </span>
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className="pt-2 flex items-center gap-2.5 flex-wrap">
              <button
                onClick={() => onSelectNode(activeTopic)}
                className="px-5 py-2.5 rounded-full bg-[#141414] hover:bg-black text-white text-xs font-semibold transition cursor-pointer shadow-sm flex items-center space-x-1.5"
              >
                <span>Дэлгэрэнгүй унших</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={onOpenMindMap}
                className="px-5 py-2.5 rounded-full bg-white/90 hover:bg-white text-[#141414] text-xs font-semibold transition cursor-pointer border border-[#EAA2C0] flex items-center space-x-1.5 shadow-2xs"
              >
                <Network className="w-3.5 h-3.5 text-[#D81B60]" />
                <span>JustTugo's Statistic дээр харах</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
