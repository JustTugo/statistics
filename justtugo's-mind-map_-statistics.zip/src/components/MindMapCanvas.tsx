import React, { useRef, useEffect, useCallback } from 'react';
import { GraphNode, StudyStatus } from '../types';
import { BRANCH_CONFIG } from '../data/graphData';
import { ZoomIn, ZoomOut, RotateCcw, Sun, Moon, Maximize2, Minimize2 } from 'lucide-react';

interface MindMapCanvasProps {
  root: GraphNode;
  branches: GraphNode[];
  nodesMap: Record<string, GraphNode>;
  selectedNode: GraphNode | null;
  expandedBranches: Set<string>;
  onSelectNode: (node: GraphNode, toggleBranch?: boolean) => void;
  studyStatus: Record<string, StudyStatus>;
  bookmarks: Record<string, boolean>;
  isDrawerOpen: boolean;
  fitSignal: number;
  theme?: 'light' | 'dark';
  onToggleTheme?: () => void;
  onToggleExpandAll?: () => void;
}

export const MindMapCanvas: React.FC<MindMapCanvasProps> = ({
  root,
  branches,
  nodesMap,
  selectedNode,
  expandedBranches,
  onSelectNode,
  studyStatus,
  bookmarks,
  isDrawerOpen,
  fitSignal,
  theme = 'light',
  onToggleTheme,
  onToggleExpandAll
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  const camRef = useRef({ x: 0, y: 0, k: 0.95 });
  const rafRef = useRef<number | null>(null);
  const scheduledRafRef = useRef<boolean>(false);

  const isDark = theme === 'dark';
  const canvasBg = isDark ? '#121212' : '#FAF8F5';
  const textColor = isDark ? '#EDEDED' : '#222222';
  const textStroke = isDark ? '#121212' : '#FAF8F5';

  // Visible nodes: root + all branches + child nodes of expanded branches
  const visibleNodes: GraphNode[] = [
    root,
    ...branches,
    ...branches.flatMap(b => (expandedBranches.has(b.i) ? b.k || [] : []))
  ];

  // Helper: chain of ancestor IDs for path highlighting
  const chainOf = (node: GraphNode | null): Set<string> => {
    const s = new Set<string>();
    let curr: GraphNode | undefined = node || undefined;
    while (curr) {
      s.add(curr.i);
      curr = curr.p ? nodesMap[curr.p] : undefined;
    }
    return s;
  };

  const selectedChain = chainOf(selectedNode);

  // Branch color map
  const branchColorMap = useRef<Record<string, string>>({});
  BRANCH_CONFIG.forEach(b => {
    branchColorMap.current[b.id] = b.color;
  });

  // Apply camera transform to #cam group via direct DOM manipulation
  const applyTransform = useCallback(() => {
    const camG = document.getElementById('cam');
    if (camG) {
      camG.setAttribute(
        'transform',
        `translate(${camRef.current.x.toFixed(1)} ${camRef.current.y.toFixed(1)}) scale(${camRef.current.k.toFixed(3)})`
      );
    }
    scheduledRafRef.current = false;
  }, []);

  const queueTransform = useCallback(() => {
    if (!scheduledRafRef.current) {
      scheduledRafRef.current = true;
      requestAnimationFrame(applyTransform);
    }
  }, [applyTransform]);

  // Fit camera smoothly to specific nodes
  const fitToNodes = useCallback(
    (nodes: GraphNode[], maxK = 1.05, animate = true) => {
      const svg = svgRef.current;
      if (!svg || nodes.length === 0) return;
      const W = svg.clientWidth || window.innerWidth;
      const H = svg.clientHeight || window.innerHeight;
      if (!W || !H) return;

      const panelWidth = isDrawerOpen && W > 768 ? Math.min(460, W * 0.38) : 0;
      const xs = nodes.map(n => n.x);
      const ys = nodes.map(n => n.y);

      const x0 = Math.min(...xs) - 180;
      const x1 = Math.max(...xs) + 240;
      const y0 = Math.min(...ys) - 140;
      const y1 = Math.max(...ys) + 140;

      const availableW = Math.max(300, W - panelWidth);
      const k = Math.min(maxK, Math.max(0.25, Math.min(availableW / (x1 - x0), H / (y1 - y0))));
      const target = {
        x: availableW / 2 - ((x0 + x1) / 2) * k,
        y: H / 2 - ((y0 + y1) / 2) * k,
        k
      };

      if (rafRef.current) cancelAnimationFrame(rafRef.current);

      if (!animate) {
        camRef.current = target;
        applyTransform();
        return;
      }

      const start = { ...camRef.current };
      const startTime = performance.now();
      const duration = 380;

      const step = (t: number) => {
        const u = Math.min(1, (t - startTime) / duration);
        const ease = 1 - Math.pow(1 - u, 3);
        camRef.current = {
          x: start.x + (target.x - start.x) * ease,
          y: start.y + (target.y - start.y) * ease,
          k: start.k + (target.k - start.k) * ease
        };
        applyTransform();
        if (u < 1) {
          rafRef.current = requestAnimationFrame(step);
        }
      };
      rafRef.current = requestAnimationFrame(step);
    },
    [applyTransform, isDrawerOpen]
  );

  // Initial fit on mount
  useEffect(() => {
    const timer = setTimeout(() => {
      fitToNodes(visibleNodes, 0.95, false);
    }, 50);
    return () => clearTimeout(timer);
  }, []);

  // Handle external fit signal
  useEffect(() => {
    if (fitSignal > 0) {
      fitToNodes(visibleNodes, 0.98, true);
    }
  }, [fitSignal]);

  // Center on selected node when selection changes
  useEffect(() => {
    if (selectedNode && selectedNode.i !== 'stat') {
      const list = [selectedNode];
      if (selectedNode.p && nodesMap[selectedNode.p]) {
        list.push(nodesMap[selectedNode.p]);
      }
      fitToNodes(list, 1.12, true);
    }
  }, [selectedNode?.i]);

  // Multi-touch gestures (Pinch-to-zoom with 2 fingers & 1-finger pan) + Mouse Wheel
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Wheel zoom
    const handleWheel = (e: WheelEvent) => {
      e.preventDefault();
      e.stopPropagation();

      const r = container.getBoundingClientRect();
      const mx = e.clientX - r.left;
      const my = e.clientY - r.top;

      let zoomFactor: number;
      if (e.ctrlKey) {
        zoomFactor = Math.pow(1.01, -e.deltaY);
      } else {
        zoomFactor = e.deltaY < 0 ? 1.12 : 1 / 1.12;
      }

      const newK = Math.min(4.0, Math.max(0.18, camRef.current.k * zoomFactor));

      camRef.current.x = mx - (mx - camRef.current.x) * (newK / camRef.current.k);
      camRef.current.y = my - (my - camRef.current.y) * (newK / camRef.current.k);
      camRef.current.k = newK;
      queueTransform();
    };

    // State for Touch
    let touchMode: 'none' | 'pan' | 'pinch' = 'none';
    let touchStartX = 0;
    let touchStartY = 0;
    let camStartX = 0;
    let camStartY = 0;
    let pinchStartDist = 0;
    let pinchStartK = 1;
    let pinchMidX = 0;
    let pinchMidY = 0;
    let hasMoved = false;
    let tapTargetNodeId: string | null = null;
    let tapStartTime = 0;

    const handleTouchStart = (e: TouchEvent) => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);

      const r = container.getBoundingClientRect();

      if (e.touches.length === 1) {
        touchMode = 'pan';
        const t = e.touches[0];
        touchStartX = t.clientX;
        touchStartY = t.clientY;
        camStartX = camRef.current.x;
        camStartY = camRef.current.y;
        hasMoved = false;
        tapStartTime = performance.now();

        // Check if tapped on a node
        const target = document.elementFromPoint(t.clientX, t.clientY);
        const nodeG = target?.closest('.node-g');
        tapTargetNodeId = nodeG ? nodeG.getAttribute('data-i') : null;
      } else if (e.touches.length >= 2) {
        touchMode = 'pinch';
        hasMoved = true;
        tapTargetNodeId = null;

        const t1 = e.touches[0];
        const t2 = e.touches[1];
        pinchStartDist = Math.hypot(t2.clientX - t1.clientX, t2.clientY - t1.clientY);
        pinchStartK = camRef.current.k;

        pinchMidX = (t1.clientX + t2.clientX) / 2 - r.left;
        pinchMidY = (t1.clientY + t2.clientY) / 2 - r.top;
        camStartX = camRef.current.x;
        camStartY = camRef.current.y;
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      e.preventDefault(); // Prevent browser native zoom/scroll

      const r = container.getBoundingClientRect();

      if (touchMode === 'pan' && e.touches.length === 1) {
        const t = e.touches[0];
        const dx = t.clientX - touchStartX;
        const dy = t.clientY - touchStartY;

        if (Math.hypot(dx, dy) > 6) {
          hasMoved = true;
        }

        if (hasMoved) {
          camRef.current.x = camStartX + dx;
          camRef.current.y = camStartY + dy;
          queueTransform();
        }
      } else if (touchMode === 'pinch' && e.touches.length >= 2) {
        const t1 = e.touches[0];
        const t2 = e.touches[1];
        const currentDist = Math.hypot(t2.clientX - t1.clientX, t2.clientY - t1.clientY);
        if (pinchStartDist <= 0) return;

        const currentMidX = (t1.clientX + t2.clientX) / 2 - r.left;
        const currentMidY = (t1.clientY + t2.clientY) / 2 - r.top;

        const scaleRatio = currentDist / pinchStartDist;
        const newK = Math.min(4.0, Math.max(0.18, pinchStartK * scaleRatio));

        // Focal zoom around midpoint + pan
        camRef.current.x = currentMidX - (pinchMidX - camStartX) * (newK / pinchStartK);
        camRef.current.y = currentMidY - (pinchMidY - camStartY) * (newK / pinchStartK);
        camRef.current.k = newK;
        queueTransform();
      }
    };

    const handleTouchEnd = (e: TouchEvent) => {
      if (e.touches.length === 0) {
        // Tap selection check
        if (!hasMoved && tapTargetNodeId && performance.now() - tapStartTime < 400) {
          const clicked = nodesMap[tapTargetNodeId];
          if (clicked) {
            onSelectNode(clicked, true);
          }
        }
        touchMode = 'none';
        tapTargetNodeId = null;
      } else if (e.touches.length === 1) {
        // Transitioned from 2-finger pinch back to 1-finger
        touchMode = 'pan';
        const t = e.touches[0];
        touchStartX = t.clientX;
        touchStartY = t.clientY;
        camStartX = camRef.current.x;
        camStartY = camRef.current.y;
      }
    };

    // Mouse drag for desktop
    let isMouseDown = false;
    let mouseStartX = 0;
    let mouseStartY = 0;
    let mouseCamStartX = 0;
    let mouseCamStartY = 0;
    let mouseHasMoved = false;
    let mouseTargetNodeId: string | null = null;

    const handleMouseDown = (e: MouseEvent) => {
      if (e.button !== 0 && e.button !== 1) return;
      if (rafRef.current) cancelAnimationFrame(rafRef.current);

      isMouseDown = true;
      mouseStartX = e.clientX;
      mouseStartY = e.clientY;
      mouseCamStartX = camRef.current.x;
      mouseCamStartY = camRef.current.y;
      mouseHasMoved = false;

      const targetEl = (e.target as Element)?.closest('.node-g');
      mouseTargetNodeId = e.button === 0 && targetEl ? targetEl.getAttribute('data-i') : null;
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (!isMouseDown) return;
      const dx = e.clientX - mouseStartX;
      const dy = e.clientY - mouseStartY;

      if (Math.hypot(dx, dy) > 5) {
        mouseHasMoved = true;
      }

      if (mouseHasMoved) {
        camRef.current.x = mouseCamStartX + dx;
        camRef.current.y = mouseCamStartY + dy;
        queueTransform();
      }
    };

    const handleMouseUp = (e: MouseEvent) => {
      if (isMouseDown && !mouseHasMoved && mouseTargetNodeId && e.button === 0) {
        const clicked = nodesMap[mouseTargetNodeId];
        if (clicked) {
          onSelectNode(clicked, true);
        }
      }
      isMouseDown = false;
      mouseTargetNodeId = null;
    };

    container.addEventListener('wheel', handleWheel, { passive: false });
    container.addEventListener('touchstart', handleTouchStart, { passive: false });
    container.addEventListener('touchmove', handleTouchMove, { passive: false });
    container.addEventListener('touchend', handleTouchEnd, { passive: false });
    container.addEventListener('touchcancel', handleTouchEnd, { passive: false });

    container.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);

    return () => {
      container.removeEventListener('wheel', handleWheel);
      container.removeEventListener('touchstart', handleTouchStart);
      container.removeEventListener('touchmove', handleTouchMove);
      container.removeEventListener('touchend', handleTouchEnd);
      container.removeEventListener('touchcancel', handleTouchEnd);

      container.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [nodesMap, onSelectNode, queueTransform]);

  // Zoom In / Out Buttons
  const handleZoomIn = () => {
    const container = containerRef.current;
    if (!container) return;
    const mx = container.clientWidth / 2;
    const my = container.clientHeight / 2;
    const newK = Math.min(4.0, camRef.current.k * 1.25);
    camRef.current.x = mx - (mx - camRef.current.x) * (newK / camRef.current.k);
    camRef.current.y = my - (my - camRef.current.y) * (newK / camRef.current.k);
    camRef.current.k = newK;
    applyTransform();
  };

  const handleZoomOut = () => {
    const container = containerRef.current;
    if (!container) return;
    const mx = container.clientWidth / 2;
    const my = container.clientHeight / 2;
    const newK = Math.max(0.18, camRef.current.k / 1.25);
    camRef.current.x = mx - (mx - camRef.current.x) * (newK / camRef.current.k);
    camRef.current.y = my - (my - camRef.current.y) * (newK / camRef.current.k);
    camRef.current.k = newK;
    applyTransform();
  };

  const handleResetToRoot = () => {
    onSelectNode(root, false);
    fitToNodes(visibleNodes, 0.95, true);
  };

  const isAllExpanded = expandedBranches.size === branches.length;

  return (
    <div
      ref={containerRef}
      style={{ backgroundColor: canvasBg, touchAction: 'none' }}
      className="relative w-full h-full overflow-hidden select-none cursor-grab active:cursor-grabbing"
    >
      <svg
        ref={svgRef}
        id="sv"
        className="w-full h-full block"
        role="group"
        aria-label="JustTugo's Statistic Interactive Mind Map"
      >
        <defs>
          {/* Subtle grid pattern */}
          <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
            <circle
              cx="20"
              cy="20"
              r="1"
              fill={isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)'}
            />
          </pattern>
        </defs>

        <rect width="100%" height="100%" fill="url(#grid)" />

        <g id="cam" style={{ willChange: 'transform', transformOrigin: '0 0' }}>
          {/* 1. EDGES / SYNAPSES: ROOT TO BRANCHES & BRANCHES TO LEAVES */}
          {visibleNodes.map(node => {
            if (!node.p) return null;
            const parent = nodesMap[node.p];
            if (!parent) return null;

            const isBranchEdge = parent.i === 'stat';
            const branchId = isBranchEdge ? node.i : parent.i;
            const branchColor = branchColorMap.current[branchId] || '#FF6B8B';

            // Only show child edges if branch is expanded
            if (!isBranchEdge && !expandedBranches.has(parent.i)) {
              return null;
            }

            const isPathActive = selectedChain.has(node.i);

            // Compute graceful organic curve
            let pathD = '';
            if (isBranchEdge) {
              // Center to Branch Node
              const dx = node.x - parent.x;
              const dy = node.y - parent.y;

              if (node.i === 'b1') {
                pathD = `M ${parent.x} ${parent.y - 58} L ${node.x} ${node.y + 18}`;
              } else if (node.i === 'b5') {
                pathD = `M ${parent.x} ${parent.y + 58} L ${node.x} ${node.y - 18}`;
              } else {
                const cx1 = parent.x + dx * 0.45;
                const cy1 = parent.y + dy * 0.15;
                const cx2 = parent.x + dx * 0.75;
                const cy2 = parent.y + dy * 0.85;
                pathD = `M ${parent.x} ${parent.y} C ${cx1} ${cy1}, ${cx2} ${cy2}, ${node.x} ${node.y}`;
              }
            } else {
              // Branch Node to Leaf Concept
              const isBranch1 = parent.i === 'b1';
              const isBranch5 = parent.i === 'b5';

              if (isBranch1 || isBranch5) {
                const midY = (parent.y + node.y) / 2;
                pathD = `M ${parent.x} ${parent.y} C ${parent.x} ${midY}, ${node.x} ${midY}, ${node.x} ${node.y}`;
              } else {
                const midX = (parent.x + node.x) / 2;
                pathD = `M ${parent.x} ${parent.y} C ${midX} ${parent.y}, ${midX} ${node.y}, ${node.x} ${node.y}`;
              }
            }

            return (
              <path
                key={`edge-${node.i}`}
                d={pathD}
                fill="none"
                stroke={branchColor}
                strokeWidth={isBranchEdge ? (isPathActive ? 3.5 : 2.4) : (isPathActive ? 2.2 : 1.4)}
                strokeOpacity={isPathActive ? 0.95 : 0.65}
                strokeLinecap="round"
                className="transition-all duration-300 pointer-events-none"
              />
            );
          })}

          {/* 2. ROOT SOMA NODE: CENTER HUB WITH JUSTTUGO BRANDING */}
          <g
            data-i="stat"
            className="node-g cursor-pointer"
            transform={`translate(${root.x}, ${root.y})`}
          >
            {/* Outer Glow Halo */}
            <circle
              r={68}
              fill="none"
              stroke="#FF6B8B"
              strokeWidth="2"
              strokeOpacity="0.4"
            />
            {/* Main Central Pearl */}
            <circle
              r={58}
              fill={isDark ? '#181818' : '#FFFFFF'}
              stroke="#FF6B8B"
              strokeWidth="4"
              className="shadow-xl"
            />
            {/* Root Inner Text */}
            <text
              x={0}
              y={-14}
              dominantBaseline="central"
              textAnchor="middle"
              className="text-[13px] font-extrabold tracking-tight"
              style={{ fill: isDark ? '#FFFFFF' : '#141414' }}
            >
              СТАТИСТИК
            </text>
            <text
              x={0}
              y={4}
              dominantBaseline="central"
              textAnchor="middle"
              className="text-[10px] font-mono tracking-wider"
              style={{ fill: '#FF6B8B' }}
            >
              МЕТОДОЛОГИ
            </text>
            <text
              x={0}
              y={20}
              dominantBaseline="central"
              textAnchor="middle"
              className="text-[9px] font-mono font-semibold"
              style={{ fill: isDark ? '#888888' : '#777777' }}
            >
              By JustTugo
            </text>
          </g>

          {/* 3. BRANCH HUBS: 9 MAJOR COLOR-CODED HUBS WITH LABELS */}
          {branches.map(branch => {
            const isSelected = selectedNode?.i === branch.i;
            const branchColor = branchColorMap.current[branch.i] || '#FF6B8B';
            const isExpanded = expandedBranches.has(branch.i);
            const childCount = branch.k?.length || 0;

            const r = 17;
            const isTop = branch.i === 'b1';
            const isBottom = branch.i === 'b5';

            let labelX = 0;
            let labelY = 0;
            let labelAnchor: 'start' | 'middle' | 'end' = 'middle';

            if (isTop) {
              labelX = 0;
              labelY = 28;
              labelAnchor = 'middle';
            } else if (isBottom) {
              labelX = 0;
              labelY = -28;
              labelAnchor = 'middle';
            } else if (branch.x < 0) {
              // Left hemisphere: title extends outward/aligned left
              labelX = -24;
              labelY = -12;
              labelAnchor = 'end';
            } else {
              // Right hemisphere: title extends outward/aligned right
              labelX = 24;
              labelY = -12;
              labelAnchor = 'start';
            }

            return (
              <g
                key={branch.i}
                data-i={branch.i}
                className="node-g cursor-pointer"
                transform={`translate(${branch.x}, ${branch.y})`}
              >
                {/* Bubble outer halo when selected */}
                {isSelected && (
                  <circle
                    r={r + 6}
                    fill={`${branchColor}25`}
                    stroke={branchColor}
                    strokeWidth="1.5"
                  />
                )}

                {/* Circular bubble with branch number */}
                <circle
                  r={r}
                  fill={branchColor}
                  stroke="#FFFFFF"
                  strokeWidth="2.5"
                  className="transition-transform duration-200 hover:scale-110 shadow-sm"
                />

                <text
                  x={0}
                  y={0.5}
                  dominantBaseline="central"
                  textAnchor="middle"
                  className="text-[11px] font-mono font-bold fill-white pointer-events-none select-none"
                >
                  {branch.n}
                </text>

                {/* Expand / Collapse Indicator badge */}
                {!isExpanded && childCount > 0 && (
                  <g transform={`translate(${branch.x > 0 ? 12 : -12}, 12)`}>
                    <circle r={7} fill="#141414" stroke="#FFFFFF" strokeWidth="1.5" />
                    <text
                      x={0}
                      y={0.5}
                      dominantBaseline="central"
                      textAnchor="middle"
                      className="text-[8px] font-mono font-bold fill-white pointer-events-none select-none"
                    >
                      +{childCount}
                    </text>
                  </g>
                )}

                {/* Branch Title */}
                <text
                  x={labelX}
                  y={labelY}
                  dominantBaseline="central"
                  textAnchor={labelAnchor}
                  className="text-[13.5px] font-bold tracking-tight transition-colors pointer-events-none select-none"
                  style={{
                    fill: isSelected ? branchColor : textColor,
                    paintOrder: 'stroke',
                    stroke: textStroke,
                    strokeWidth: '3.5px',
                    strokeLinejoin: 'round'
                  }}
                >
                  {branch.t}
                </text>
              </g>
            );
          })}

          {/* 4. LEAF CONCEPT NODES: DELICATE HOLLOW RING PEARLS WITH LABELS */}
          {visibleNodes.map(node => {
            if (node.lv !== 2 || !node.p) return null;

            const isSelected = selectedNode?.i === node.i;
            const parent = nodesMap[node.p];
            const branchColor = branchColorMap.current[node.p] || '#FF6B8B';
            const isBookmarked = Boolean(bookmarks[node.i]);

            const isBranch1 = node.p === 'b1';
            const isBranch5 = node.p === 'b5';
            const isRightSide = parent ? node.x > parent.x : true;

            // Anchor & text positioning
            let tx = isRightSide ? 14 : -14;
            let ty = 0;
            let anchor: 'start' | 'middle' | 'end' = isRightSide ? 'start' : 'end';

            if (isBranch1) {
              tx = 0;
              ty = -14;
              anchor = 'middle';
            } else if (isBranch5) {
              tx = 0;
              ty = 16;
              anchor = 'middle';
            }

            const label = `${node.t}${isBookmarked ? ' ★' : ''}`;

            return (
              <g
                key={node.i}
                data-i={node.i}
                className="node-g cursor-pointer"
                transform={`translate(${node.x}, ${node.y})`}
              >
                {/* Selection Ring */}
                {isSelected && (
                  <circle
                    r={11}
                    fill={`${branchColor}25`}
                    stroke={branchColor}
                    strokeWidth="1.5"
                  />
                )}

                {/* Delicate Hollow Ring Pearl */}
                <circle
                  r={5.5}
                  fill={isSelected ? branchColor : canvasBg}
                  stroke={branchColor}
                  strokeWidth="2"
                  className="transition-colors duration-200 hover:scale-125"
                />

                {/* Concept Label */}
                <text
                  x={tx}
                  y={ty}
                  dominantBaseline="central"
                  textAnchor={anchor}
                  className={`text-[12px] transition-colors pointer-events-none select-none ${
                    isSelected ? 'font-bold' : 'font-medium'
                  }`}
                  style={{
                    fill: isSelected ? branchColor : (isDark ? '#E5E5E5' : '#222222'),
                    paintOrder: 'stroke',
                    stroke: textStroke,
                    strokeWidth: '3px',
                    strokeLinejoin: 'round'
                  }}
                >
                  {label}
                </text>
              </g>
            );
          })}
        </g>
      </svg>

      {/* Floating Top-Left Badge: JustTugo's Statistic */}
      <div className="absolute top-4 left-5 z-20 pointer-events-none">
        <div
          style={{
            backgroundColor: isDark ? 'rgba(30,30,30,0.85)' : 'rgba(255,255,255,0.88)',
            borderColor: isDark ? '#333333' : '#E8E2D5',
            color: isDark ? '#E0E0E0' : '#141414'
          }}
          className="flex items-center space-x-2 px-3.5 py-1.5 rounded-full border backdrop-blur-md shadow-xs"
        >
          <span className="w-2 h-2 rounded-full bg-[#FF6B8B] animate-pulse" />
          <span className="text-xs font-bold font-sans tracking-tight">JustTugo's Statistic</span>
          <span className="text-[10px] font-mono text-[#888888]">
            ({branches.length} салбар)
          </span>
        </div>
      </div>

      {/* Floating Bottom Center / Right Canvas Controls */}
      <div className="absolute bottom-5 right-5 z-20 flex items-center space-x-2">
        {onToggleExpandAll && (
          <button
            onClick={onToggleExpandAll}
            style={{
              backgroundColor: isDark ? '#242424' : '#FFFFFF',
              borderColor: isDark ? '#383838' : '#E2D9CC',
              color: isDark ? '#EDEDED' : '#141414'
            }}
            className="p-2.5 rounded-full border shadow-md hover:scale-105 transition cursor-pointer flex items-center justify-center space-x-1 px-3 text-xs font-semibold"
            title={isAllExpanded ? 'Салбаруудыг хумих' : 'Бүх сэдвийг дэлгэх'}
          >
            {isAllExpanded ? (
              <>
                <Minimize2 className="w-3.5 h-3.5 text-[#FF6B8B]" />
                <span className="hidden sm:inline">Хумих</span>
              </>
            ) : (
              <>
                <Maximize2 className="w-3.5 h-3.5 text-[#64B5F6]" />
                <span className="hidden sm:inline">Бүгдийг дэлгэх</span>
              </>
            )}
          </button>
        )}

        <button
          onClick={handleZoomIn}
          style={{
            backgroundColor: isDark ? '#242424' : '#FFFFFF',
            borderColor: isDark ? '#383838' : '#E2D9CC',
            color: isDark ? '#EDEDED' : '#141414'
          }}
          className="p-2.5 rounded-full border shadow-md hover:scale-105 transition cursor-pointer flex items-center justify-center"
          title="Томруулах (+)"
          aria-label="Zoom in"
        >
          <ZoomIn className="w-4 h-4" />
        </button>

        <button
          onClick={handleZoomOut}
          style={{
            backgroundColor: isDark ? '#242424' : '#FFFFFF',
            borderColor: isDark ? '#383838' : '#E2D9CC',
            color: isDark ? '#EDEDED' : '#141414'
          }}
          className="p-2.5 rounded-full border shadow-md hover:scale-105 transition cursor-pointer flex items-center justify-center"
          title="Багасгах (-)"
          aria-label="Zoom out"
        >
          <ZoomOut className="w-4 h-4" />
        </button>

        <button
          onClick={handleResetToRoot}
          style={{
            backgroundColor: isDark ? '#242424' : '#FFFFFF',
            borderColor: isDark ? '#383838' : '#E2D9CC',
            color: isDark ? '#EDEDED' : '#141414'
          }}
          className="p-2.5 rounded-full border shadow-md hover:scale-105 transition cursor-pointer flex items-center justify-center"
          title="Төвд шилжих (Reset)"
          aria-label="Reset view"
        >
          <RotateCcw className="w-4 h-4" />
        </button>

        {onToggleTheme && (
          <button
            onClick={onToggleTheme}
            style={{
              backgroundColor: isDark ? '#242424' : '#FFFFFF',
              borderColor: isDark ? '#383838' : '#E2D9CC',
              color: isDark ? '#FAD968' : '#141414'
            }}
            className="p-2.5 rounded-full border shadow-md hover:scale-105 transition cursor-pointer flex items-center justify-center"
            title={isDark ? 'Гэгээлэг горим' : 'Харанхуй горим'}
            aria-label="Toggle theme"
          >
            {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
        )}
      </div>
    </div>
  );
};
