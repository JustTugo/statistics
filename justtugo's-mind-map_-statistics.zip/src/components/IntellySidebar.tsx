import React from 'react';
import {
  LayoutDashboard,
  Network,
  ListTree,
  GitFork,
  Bookmark,
  Calculator,
  RotateCcw,
  Sun,
  Moon,
  X,
  Smartphone
} from 'lucide-react';

interface IntellySidebarProps {
  currentView: 'dashboard' | 'mindmap' | 'list';
  onChangeView: (view: 'dashboard' | 'mindmap' | 'list') => void;
  onOpenMatrix: () => void;
  onOpenCalculator: () => void;
  onOpenBookmarks: () => void;
  onResetView: () => void;
  bookmarksCount: number;
  theme?: 'light' | 'dark';
  onToggleTheme?: () => void;
  isOpenMobile?: boolean;
  onCloseMobile?: () => void;
  onOpenInstallModal?: () => void;
}

export const IntellySidebar: React.FC<IntellySidebarProps> = ({
  currentView,
  onChangeView,
  onOpenMatrix,
  onOpenCalculator,
  onOpenBookmarks,
  onResetView,
  bookmarksCount,
  theme = 'light',
  onToggleTheme,
  isOpenMobile = false,
  onCloseMobile,
  onOpenInstallModal
}) => {
  const isDark = theme === 'dark';

  const handleNav = (fn: () => void) => {
    fn();
    if (onCloseMobile) onCloseMobile();
  };

  const sidebarContent = (
    <aside className="w-64 md:w-56 bg-[#141414] text-[#E0E0E0] p-5 flex flex-col justify-between shrink-0 relative select-none h-full border-r border-[#222222]">
      <div className="space-y-6">
        {/* Brand Logo & Mobile Close button */}
        <div className="pt-1 flex items-center justify-between">
          <div>
            <div className="flex items-center space-x-1.5">
              <span className="text-xl font-black tracking-tight text-white font-sans">
                By JustTugo
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-[#FF6B8B]" />
            </div>
            <p className="text-[10px] font-mono text-[#777777] mt-0.5 tracking-wider">
              JUSTTUGO'S STATISTIC
            </p>
          </div>

          {onCloseMobile && (
            <button
              onClick={onCloseMobile}
              className="md:hidden p-1.5 rounded-lg text-[#888888] hover:text-white hover:bg-[#222222] transition cursor-pointer"
              aria-label="Хаах"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Navigation List */}
        <div className="space-y-1">
          <div className="text-[10px] font-mono tracking-wider text-[#707070] uppercase px-2 mb-2 font-semibold">
            Цэс
          </div>

          <button
            onClick={() => handleNav(() => onChangeView('dashboard'))}
            className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl text-xs font-medium transition cursor-pointer ${
              currentView === 'dashboard'
                ? 'bg-[#242424] text-white shadow-xs font-semibold'
                : 'text-[#9E9E9E] hover:text-white hover:bg-[#1E1E1E]'
            }`}
          >
            <LayoutDashboard className="w-4 h-4 shrink-0 text-[#FF6B8B]" />
            <span>Dashboard</span>
          </button>

          <button
            onClick={() => handleNav(() => onChangeView('mindmap'))}
            className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl text-xs font-medium transition cursor-pointer ${
              currentView === 'mindmap'
                ? 'bg-[#242424] text-white shadow-xs font-semibold'
                : 'text-[#9E9E9E] hover:text-white hover:bg-[#1E1E1E]'
            }`}
          >
            <Network className="w-4 h-4 shrink-0 text-[#64B5F6]" />
            <span>Mind Map</span>
          </button>

          <button
            onClick={() => handleNav(() => onChangeView('list'))}
            className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl text-xs font-medium transition cursor-pointer ${
              currentView === 'list'
                ? 'bg-[#242424] text-white shadow-xs font-semibold'
                : 'text-[#9E9E9E] hover:text-white hover:bg-[#1E1E1E]'
            }`}
          >
            <ListTree className="w-4 h-4 shrink-0 text-[#FFD54F]" />
            <span>Topics (9 салбар)</span>
          </button>

          <button
            onClick={() => handleNav(onOpenMatrix)}
            className="w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl text-xs font-medium text-[#9E9E9E] hover:text-white hover:bg-[#1E1E1E] transition cursor-pointer"
          >
            <GitFork className="w-4 h-4 shrink-0 text-[#81C784]" />
            <span>Decision tree</span>
          </button>

          <button
            onClick={() => handleNav(onOpenCalculator)}
            className="w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl text-xs font-medium text-[#9E9E9E] hover:text-white hover:bg-[#1E1E1E] transition cursor-pointer"
          >
            <Calculator className="w-4 h-4 shrink-0 text-[#BA68C8]" />
            <span>Calculators</span>
          </button>

          <button
            onClick={() => handleNav(onOpenBookmarks)}
            className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium text-[#9E9E9E] hover:text-white hover:bg-[#1E1E1E] transition cursor-pointer"
          >
            <div className="flex items-center space-x-3">
              <Bookmark className="w-4 h-4 shrink-0 text-[#E0E0E0]" />
              <span>Хадгалсан</span>
            </div>
            {bookmarksCount > 0 && (
              <span className="text-[10px] font-mono bg-[#FF6B8B] text-black font-bold px-1.5 py-0.2 rounded-full">
                {bookmarksCount}
              </span>
            )}
          </button>

          {onOpenInstallModal && (
            <button
              onClick={() => handleNav(onOpenInstallModal)}
              className="w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl text-xs font-semibold text-[#FF6B8B] hover:text-white hover:bg-[#1E1E1E] transition cursor-pointer mt-1 border border-[#FF6B8B]/20 bg-[#FF6B8B]/10"
            >
              <Smartphone className="w-4 h-4 shrink-0 text-[#FF6B8B]" />
              <span>Android / App татах</span>
            </button>
          )}
        </div>
      </div>

      {/* Footer Controls: Theme Toggle & Reset (Tools & Practice section removed as requested) */}
      <div className="pt-4 border-t border-[#222222] space-y-2">
        {onToggleTheme && (
          <button
            onClick={onToggleTheme}
            className="w-full flex items-center space-x-3 px-3 py-2 rounded-xl text-xs font-medium text-[#9E9E9E] hover:text-white hover:bg-[#1E1E1E] transition cursor-pointer"
          >
            {isDark ? (
              <>
                <Sun className="w-4 h-4 shrink-0 text-amber-400" />
                <span>Гэгээлэг горим</span>
              </>
            ) : (
              <>
                <Moon className="w-4 h-4 shrink-0 text-slate-400" />
                <span>Харанхуй горим</span>
              </>
            )}
          </button>
        )}

        <button
          onClick={() => handleNav(onResetView)}
          className="w-full flex items-center space-x-3 px-3 py-2 rounded-xl text-xs font-medium text-[#7E7E7E] hover:text-white hover:bg-[#1E1E1E] transition cursor-pointer"
        >
          <RotateCcw className="w-4 h-4 shrink-0" />
          <span>Home / Reset</span>
        </button>
      </div>
    </aside>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar */}
      <div className="hidden md:flex h-full shrink-0">
        {sidebarContent}
      </div>

      {/* Mobile Modal Drawer Sidebar with Backdrop */}
      {isOpenMobile && (
        <div className="md:hidden fixed inset-0 z-50 flex">
          <div
            className="fixed inset-0 bg-black/70 backdrop-blur-xs transition-opacity"
            onClick={onCloseMobile}
          />
          <div className="relative z-10 h-full animate-in slide-in-from-left duration-250">
            {sidebarContent}
          </div>
        </div>
      )}
    </>
  );
};
