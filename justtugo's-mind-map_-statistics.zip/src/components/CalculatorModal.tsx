import React, { useState } from 'react';
import { X, Calculator, HelpCircle, CheckCircle2 } from 'lucide-react';

interface CalculatorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CalculatorModal: React.FC<CalculatorModalProps> = ({
  isOpen,
  onClose
}) => {
  // Active Tab: 'z-score' | 't-test' | 'ind-t' | 'chi-sq'
  const [activeTab, setActiveTab] = useState<'z-score' | 't-test' | 'ind-t' | 'chi-sq'>('z-score');

  // 1. Z-Score State
  const [zX, setZX] = useState<number>(95);
  const [zMean, setZMean] = useState<number>(86);
  const [zSd, setZSd] = useState<number>(7);

  // 2. One-Sample t State
  const [tXbar, setTXbar] = useState<number>(55);
  const [tMu, setTMu] = useState<number>(50);
  const [tS, setTS] = useState<number>(10);
  const [tN, setTN] = useState<number>(30);

  // 3. Two-Sample t State
  const [t2M1, setT2M1] = useState<number>(78);
  const [t2S1, setT2S1] = useState<number>(12);
  const [t2N1, setT2N1] = useState<number>(35);
  const [t2M2, setT2M2] = useState<number>(70);
  const [t2S2, setT2S2] = useState<number>(14);
  const [t2N2, setT2N2] = useState<number>(35);

  // 4. Chi-Square 2x2 State
  const [chiA, setChiA] = useState<number>(35);
  const [chiB, setChiB] = useState<number>(15);
  const [chiC, setChiC] = useState<number>(10);
  const [chiD, setChiD] = useState<number>(40);

  if (!isOpen) return null;

  // 1. Z-Score Calculations
  const calculatedZ = zSd !== 0 ? (zX - zMean) / zSd : 0;
  const calculatedT = 50 + 10 * calculatedZ;
  const calculatedIq = 100 + 15 * calculatedZ;
  const calculatedSat = 500 + 100 * calculatedZ;

  // 2. One-Sample t Calculations
  const calcSe = tN > 0 ? tS / Math.sqrt(tN) : 0;
  const calcTVal = calcSe !== 0 ? (tXbar - tMu) / calcSe : 0;
  const calcDf = Math.max(1, tN - 1);
  const tCrit = 2.045; // approx for df ~ 29 at alpha = 0.05
  const isTSignificant = Math.abs(calcTVal) >= tCrit;

  // 3. Independent 2-Sample t Calculations
  const df1 = Math.max(1, t2N1 - 1);
  const df2 = Math.max(1, t2N2 - 1);
  const dfTotal = df1 + df2;
  const pooledVar = dfTotal > 0 ? (df1 * (t2S1 * t2S1) + df2 * (t2S2 * t2S2)) / dfTotal : 1;
  const pooledSd = Math.sqrt(Math.max(0.0001, pooledVar));
  const seDiff = pooledSd * Math.sqrt((1 / Math.max(1, t2N1)) + (1 / Math.max(1, t2N2)));
  const t2Val = seDiff > 0 ? (t2M1 - t2M2) / seDiff : 0;
  const cohensD = pooledSd > 0 ? (t2M1 - t2M2) / pooledSd : 0;
  const t2Crit = 1.996; // approx for df ~ 68 at alpha = 0.05
  const isT2Significant = Math.abs(t2Val) >= t2Crit;

  // 4. Chi-Square 2x2 Calculations
  const chiTotal = chiA + chiB + chiC + chiD;
  const chiRow1 = chiA + chiB;
  const chiRow2 = chiC + chiD;
  const chiCol1 = chiA + chiC;
  const chiCol2 = chiB + chiD;

  const feA = chiTotal > 0 ? (chiRow1 * chiCol1) / chiTotal : 0;
  const feB = chiTotal > 0 ? (chiRow1 * chiCol2) / chiTotal : 0;
  const feC = chiTotal > 0 ? (chiRow2 * chiCol1) / chiTotal : 0;
  const feD = chiTotal > 0 ? (chiRow2 * chiCol2) / chiTotal : 0;

  const chiTermA = feA > 0 ? Math.pow(chiA - feA, 2) / feA : 0;
  const chiTermB = feB > 0 ? Math.pow(chiB - feB, 2) / feB : 0;
  const chiTermC = feC > 0 ? Math.pow(chiC - feC, 2) / feC : 0;
  const chiTermD = feD > 0 ? Math.pow(chiD - feD, 2) / feD : 0;
  const chiStat = chiTermA + chiTermB + chiTermC + chiTermD;
  const isChiSignificant = chiStat >= 3.841; // crit for df = 1 at alpha = 0.05
  const phiCoeff = chiTotal > 0 ? Math.sqrt(chiStat / chiTotal) : 0;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs p-4 sm:p-8 overflow-y-auto flex items-start justify-center select-none">
      <div className="w-full max-w-4xl bg-[#1E1E1E] border border-[#333333] rounded-[28px] shadow-2xl p-6 sm:p-8 my-8 relative text-[#F5F5F5]">
        {/* Header */}
        <div className="flex items-start justify-between pb-6 border-b border-[#333333]">
          <div>
            <div className="text-xs font-mono text-[#6B6B6B] uppercase tracking-wider mb-1 flex items-center space-x-1.5">
              <Calculator className="w-4 h-4 text-emerald-400" />
              <span>ИНТЕРАКТИВ СТАТИСТИК БОДЛОГЫН САНДБОКС</span>
            </div>
            <h2 className="text-2xl font-bold tracking-tight text-[#F5F5F5]">
              Статистик тооцоолуур
            </h2>
            <p className="text-xs text-[#A8A8A8] mt-1.5 leading-relaxed">
              Үндсэн томьёонуудын утгыг шууд өөрчлөн үр дүнг шалгах, таамаглал ба нөлөөллийн хэмжээг тооцоолох интерактив багаж.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-[#262626] text-[#A8A8A8] hover:text-white transition cursor-pointer"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center space-x-2 mt-6 pb-2 border-b border-[#2a2a2a] overflow-x-auto">
          <button
            onClick={() => setActiveTab('z-score')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer shrink-0 ${
              activeTab === 'z-score' ? 'bg-white text-[#141414]' : 'text-[#A8A8A8] hover:text-white bg-[#262626]'
            }`}
          >
            Z-оноо ба Стандарт оноо
          </button>
          <button
            onClick={() => setActiveTab('t-test')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer shrink-0 ${
              activeTab === 't-test' ? 'bg-white text-[#141414]' : 'text-[#A8A8A8] hover:text-white bg-[#262626]'
            }`}
          >
            1 түүврийн t-тест
          </button>
          <button
            onClick={() => setActiveTab('ind-t')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer shrink-0 ${
              activeTab === 'ind-t' ? 'bg-white text-[#141414]' : 'text-[#A8A8A8] hover:text-white bg-[#262626]'
            }`}
          >
            2 түүврийн t ба Коэны d
          </button>
          <button
            onClick={() => setActiveTab('chi-sq')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer shrink-0 ${
              activeTab === 'chi-sq' ? 'bg-white text-[#141414]' : 'text-[#A8A8A8] hover:text-white bg-[#262626]'
            }`}
          >
            Хи-квадрат (2x2)
          </button>
        </div>

        {/* TAB 1: Z-SCORE */}
        {activeTab === 'z-score' && (
          <div className="mt-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-[#262626] border border-[#333333] rounded-xl p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-sm text-[#F5F5F5]">Оролтын өгөгдөл</h3>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#1c1c1c] text-[#A8A8A8]">
                    z = (X - μ) / σ
                  </span>
                </div>

                <div className="space-y-3 text-xs">
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-[#A8A8A8]">Түүхий оноо (X):</span>
                      <span className="font-mono font-bold text-white">{zX}</span>
                    </div>
                    <input
                      type="range"
                      min="40"
                      max="150"
                      value={zX}
                      onChange={e => setZX(Number(e.target.value))}
                      className="w-full accent-white cursor-pointer"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-[#A8A8A8]">Дундаж (μ):</span>
                      <span className="font-mono font-bold text-white">{zMean}</span>
                    </div>
                    <input
                      type="range"
                      min="40"
                      max="120"
                      value={zMean}
                      onChange={e => setZMean(Number(e.target.value))}
                      className="w-full accent-white cursor-pointer"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-[#A8A8A8]">Стандарт хазайлт (σ):</span>
                      <span className="font-mono font-bold text-white">{zSd}</span>
                    </div>
                    <input
                      type="range"
                      min="1"
                      max="25"
                      value={zSd}
                      onChange={e => setZSd(Number(e.target.value))}
                      className="w-full accent-white cursor-pointer"
                    />
                  </div>
                </div>
              </div>

              {/* Outputs */}
              <div className="bg-[#141414] border border-[#333333] rounded-xl p-5 flex flex-col justify-between">
                <div>
                  <div className="text-xs font-mono text-[#6B6B6B] uppercase tracking-wider">
                    ТООЦООЛСОН СТАНДАРТ ОНООНУУД
                  </div>
                  <div className="mt-3 flex items-baseline space-x-3">
                    <span className="text-3xl font-extrabold text-[#F5F5F5]">
                      z = {calculatedZ >= 0 ? `+${calculatedZ.toFixed(2)}` : calculatedZ.toFixed(2)}
                    </span>
                    <span className="text-xs text-[#A8A8A8]">
                      ({calculatedZ >= 0 ? 'Дунджаас дээш' : 'Дунджаас доош'})
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 mt-4 text-center font-mono">
                    <div className="p-2.5 rounded-lg bg-[#1c1c1c] border border-[#2a2a2a]">
                      <div className="text-[10px] text-[#6B6B6B]">T-ОНОО</div>
                      <div className="text-sm font-bold text-emerald-400 mt-1">{calculatedT.toFixed(1)}</div>
                    </div>
                    <div className="p-2.5 rounded-lg bg-[#1c1c1c] border border-[#2a2a2a]">
                      <div className="text-[10px] text-[#6B6B6B]">IQ ОНОО</div>
                      <div className="text-sm font-bold text-sky-400 mt-1">{calculatedIq.toFixed(1)}</div>
                    </div>
                    <div className="p-2.5 rounded-lg bg-[#1c1c1c] border border-[#2a2a2a]">
                      <div className="text-[10px] text-[#6B6B6B]">SAT ОНОО</div>
                      <div className="text-sm font-bold text-amber-400 mt-1">{calculatedSat.toFixed(0)}</div>
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-[#2a2a2a] text-[11px] text-[#858585] leading-relaxed">
                  Хэвийн тархалтад онооны <b>68.26%</b> нь ±1σ, <b>95.44%</b> нь ±2σ, <b>99.74%</b> нь ±3σ-ийн зайд оршдог.
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: ONE-SAMPLE T-TEST */}
        {activeTab === 't-test' && (
          <div className="mt-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-[#262626] border border-[#333333] rounded-xl p-5 space-y-4">
                <h3 className="font-bold text-sm text-[#F5F5F5]">Түүврийн үзүүлэлтүүд</h3>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="text-[#A8A8A8] block mb-1">Түүврийн дундаж (x̄)</label>
                    <input
                      type="number"
                      value={tXbar}
                      onChange={e => setTXbar(Number(e.target.value))}
                      className="w-full p-2 rounded bg-[#1c1c1c] border border-[#333333] text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[#A8A8A8] block mb-1">Эх олонлогийн дундаж (μ)</label>
                    <input
                      type="number"
                      value={tMu}
                      onChange={e => setTMu(Number(e.target.value))}
                      className="w-full p-2 rounded bg-[#1c1c1c] border border-[#333333] text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[#A8A8A8] block mb-1">Түүврийн хазайлт (s)</label>
                    <input
                      type="number"
                      value={tS}
                      onChange={e => setTS(Number(e.target.value))}
                      className="w-full p-2 rounded bg-[#1c1c1c] border border-[#333333] text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[#A8A8A8] block mb-1">Түүврийн хэмжээ (n)</label>
                    <input
                      type="number"
                      value={tN}
                      onChange={e => setTN(Number(e.target.value))}
                      className="w-full p-2 rounded bg-[#1c1c1c] border border-[#333333] text-white font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Results */}
              <div className="bg-[#141414] border border-[#333333] rounded-xl p-5 flex flex-col justify-between">
                <div>
                  <div className="text-xs font-mono text-[#6B6B6B] uppercase tracking-wider">
                    T-ТЕСТИЙН ҮР ДҮН
                  </div>
                  <div className="mt-3 p-4 rounded-xl bg-[#1c1c1c] border border-[#2a2a2a] space-y-2 font-mono">
                    <div className="text-xs text-[#A8A8A8]">
                      SE = {tS} / √{tN} = <span className="text-white font-bold">{calcSe.toFixed(3)}</span>
                    </div>
                    <div className="text-2xl font-extrabold text-[#F5F5F5]">
                      t({calcDf}) = {calcTVal.toFixed(2)}
                    </div>
                    <div className="text-xs text-[#6B6B6B]">
                      Критик утга (α = 0.05, 2-tailed): ±{tCrit.toFixed(3)}
                    </div>
                  </div>

                  <div
                    className={`mt-4 p-4 rounded-xl border text-xs leading-relaxed ${
                      isTSignificant
                        ? 'bg-emerald-950/30 border-emerald-800 text-emerald-300'
                        : 'bg-amber-950/30 border-amber-800 text-amber-300'
                    }`}
                  >
                    <div className="font-bold flex items-center space-x-1 mb-1">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>{isTSignificant ? 'H0 няцаагдана (p < .05)' : 'H0 няцаагдахгүй (p > .05)'}</span>
                    </div>
                    <span>
                      {isTSignificant
                        ? `Түүврийн дундаж (x̄ = ${tXbar}) нь популяцийн норм дундаж (μ = ${tMu})-аас статистик ач холбогдолтойгоор ялгаатай байна.`
                        : `Түүврийн дундаж болон популяцийн хооронд статистик ач холбогдолтой ялгаа илэрсэнгүй.`}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: INDEPENDENT 2-SAMPLE T-TEST */}
        {activeTab === 'ind-t' && (
          <div className="mt-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-[#262626] border border-[#333333] rounded-xl p-5 space-y-4">
                <h3 className="font-bold text-sm text-[#F5F5F5]">2 Бүлгийн өгөгдөл</h3>

                <div className="space-y-4 text-xs">
                  <div className="p-3 bg-[#1c1c1c] rounded-lg border border-[#333333]">
                    <div className="font-semibold text-emerald-400 mb-2">1-р Бүлэг (ж: Туршилт)</div>
                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <label className="text-[#888888] block mb-0.5">Mean (x̄₁)</label>
                        <input
                          type="number"
                          value={t2M1}
                          onChange={e => setT2M1(Number(e.target.value))}
                          className="w-full p-1.5 rounded bg-[#262626] border border-[#383838] text-white font-mono"
                        />
                      </div>
                      <div>
                        <label className="text-[#888888] block mb-0.5">SD (s₁)</label>
                        <input
                          type="number"
                          value={t2S1}
                          onChange={e => setT2S1(Number(e.target.value))}
                          className="w-full p-1.5 rounded bg-[#262626] border border-[#383838] text-white font-mono"
                        />
                      </div>
                      <div>
                        <label className="text-[#888888] block mb-0.5">N (n₁)</label>
                        <input
                          type="number"
                          value={t2N1}
                          onChange={e => setT2N1(Number(e.target.value))}
                          className="w-full p-1.5 rounded bg-[#262626] border border-[#383838] text-white font-mono"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="p-3 bg-[#1c1c1c] rounded-lg border border-[#333333]">
                    <div className="font-semibold text-sky-400 mb-2">2-р Бүлэг (ж: Хяналт)</div>
                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <label className="text-[#888888] block mb-0.5">Mean (x̄₂)</label>
                        <input
                          type="number"
                          value={t2M2}
                          onChange={e => setT2M2(Number(e.target.value))}
                          className="w-full p-1.5 rounded bg-[#262626] border border-[#383838] text-white font-mono"
                        />
                      </div>
                      <div>
                        <label className="text-[#888888] block mb-0.5">SD (s₂)</label>
                        <input
                          type="number"
                          value={t2S2}
                          onChange={e => setT2S2(Number(e.target.value))}
                          className="w-full p-1.5 rounded bg-[#262626] border border-[#383838] text-white font-mono"
                        />
                      </div>
                      <div>
                        <label className="text-[#888888] block mb-0.5">N (n₂)</label>
                        <input
                          type="number"
                          value={t2N2}
                          onChange={e => setT2N2(Number(e.target.value))}
                          className="w-full p-1.5 rounded bg-[#262626] border border-[#383838] text-white font-mono"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Output */}
              <div className="bg-[#141414] border border-[#333333] rounded-xl p-5 flex flex-col justify-between">
                <div>
                  <div className="text-xs font-mono text-[#6B6B6B] uppercase tracking-wider">
                    ХОЁР БҮЛГИЙН T-ТЕСТИЙН ҮР ДҮН
                  </div>

                  <div className="mt-3 p-4 rounded-xl bg-[#1c1c1c] border border-[#2a2a2a] space-y-2 font-mono">
                    <div className="text-2xl font-extrabold text-[#F5F5F5]">
                      t({dfTotal}) = {t2Val.toFixed(2)}
                    </div>
                    <div className="text-xs text-[#A8A8A8]">
                      Нөлөөллийн хэмжээ (Cohen's d) = <span className="text-emerald-400 font-bold">{cohensD.toFixed(2)}</span>
                    </div>
                    <div className="text-xs text-[#6B6B6B]">
                      Критик утга: ±{t2Crit.toFixed(3)}
                    </div>
                  </div>

                  <div
                    className={`mt-4 p-4 rounded-xl border text-xs leading-relaxed ${
                      isT2Significant
                        ? 'bg-emerald-950/30 border-emerald-800 text-emerald-300'
                        : 'bg-amber-950/30 border-amber-800 text-amber-300'
                    }`}
                  >
                    <div className="font-bold flex items-center space-x-1 mb-1">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>{isT2Significant ? 'Ялгаа ач холбогдолтой (p < .05)' : 'Ялгаа ач холбогдолгүй (p > .05)'}</span>
                    </div>
                    <span>
                      {Math.abs(cohensD) < 0.2
                        ? 'Нөлөөллийн хэмжээ өчүүхэн бага (d < 0.2).'
                        : Math.abs(cohensD) < 0.5
                        ? 'Нөлөөллийн хэмжээ бага (Small effect, d ~ 0.2).'
                        : Math.abs(cohensD) < 0.8
                        ? 'Нөлөөллийн хэмжээ дунд зэрэг (Medium effect, d ~ 0.5).'
                        : 'Нөлөөллийн хэмжээ их (Large effect, d ≥ 0.8).'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: CHI-SQUARE */}
        {activeTab === 'chi-sq' && (
          <div className="mt-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-[#262626] border border-[#333333] rounded-xl p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-sm text-[#F5F5F5]">2x2 Хүснэгт (Ажиглагдсан давтамж fo)</h3>
                  <span className="text-[10px] font-mono text-[#858585]">Нийт N = {chiTotal}</span>
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="p-3 bg-[#1c1c1c] rounded-lg border border-[#333333]">
                    <label className="text-[#888888] block mb-1">Нүд A (fo₁₁)</label>
                    <input
                      type="number"
                      value={chiA}
                      onChange={e => setChiA(Number(e.target.value))}
                      className="w-full p-2 rounded bg-[#262626] border border-[#383838] text-white font-mono"
                    />
                    <span className="text-[10px] font-mono text-[#666666] mt-1 block">fe = {feA.toFixed(1)}</span>
                  </div>
                  <div className="p-3 bg-[#1c1c1c] rounded-lg border border-[#333333]">
                    <label className="text-[#888888] block mb-1">Нүд B (fo₁₂)</label>
                    <input
                      type="number"
                      value={chiB}
                      onChange={e => setChiB(Number(e.target.value))}
                      className="w-full p-2 rounded bg-[#262626] border border-[#383838] text-white font-mono"
                    />
                    <span className="text-[10px] font-mono text-[#666666] mt-1 block">fe = {feB.toFixed(1)}</span>
                  </div>
                  <div className="p-3 bg-[#1c1c1c] rounded-lg border border-[#333333]">
                    <label className="text-[#888888] block mb-1">Нүд C (fo₂₁)</label>
                    <input
                      type="number"
                      value={chiC}
                      onChange={e => setChiC(Number(e.target.value))}
                      className="w-full p-2 rounded bg-[#262626] border border-[#383838] text-white font-mono"
                    />
                    <span className="text-[10px] font-mono text-[#666666] mt-1 block">fe = {feC.toFixed(1)}</span>
                  </div>
                  <div className="p-3 bg-[#1c1c1c] rounded-lg border border-[#333333]">
                    <label className="text-[#888888] block mb-1">Нүд D (fo₂₂)</label>
                    <input
                      type="number"
                      value={chiD}
                      onChange={e => setChiD(Number(e.target.value))}
                      className="w-full p-2 rounded bg-[#262626] border border-[#383838] text-white font-mono"
                    />
                    <span className="text-[10px] font-mono text-[#666666] mt-1 block">fe = {feD.toFixed(1)}</span>
                  </div>
                </div>
              </div>

              {/* Output */}
              <div className="bg-[#141414] border border-[#333333] rounded-xl p-5 flex flex-col justify-between">
                <div>
                  <div className="text-xs font-mono text-[#6B6B6B] uppercase tracking-wider">
                    ХИ-КВАДРАТЫН ДҮГНЭЛТ
                  </div>

                  <div className="mt-3 p-4 rounded-xl bg-[#1c1c1c] border border-[#2a2a2a] space-y-2 font-mono">
                    <div className="text-2xl font-extrabold text-[#F5F5F5]">
                      χ²(1) = {chiStat.toFixed(2)}
                    </div>
                    <div className="text-xs text-emerald-400 font-semibold">
                      Фи коэффициент (φ) = {phiCoeff.toFixed(2)} (Холбооны хүч)
                    </div>
                    <div className="text-xs text-[#6B6B6B]">
                      Критик утга (df = 1, α = 0.05): 3.841
                    </div>
                  </div>

                  <div
                    className={`mt-4 p-4 rounded-xl border text-xs leading-relaxed ${
                      isChiSignificant
                        ? 'bg-emerald-950/30 border-emerald-800 text-emerald-300'
                        : 'bg-amber-950/30 border-amber-800 text-amber-300'
                    }`}
                  >
                    {isChiSignificant
                      ? `χ² = ${chiStat.toFixed(2)} > 3.84 тул хоёр чанарын хувьсагч хоорондоо статистик ач холбогдолтойгоор хамааралтай байна (p < .05).`
                      : `χ² = ${chiStat.toFixed(2)} ≤ 3.84 тул хувьсагчид бие даасан, хамааралгүй байна (H0 няцаагдахгүй).`}
                  </div>
                </div>

                <div className="text-[11px] font-mono text-[#6B6B6B] mt-4 pt-3 border-t border-[#2a2a2a]">
                  Холбооны хувьсагчийн тайлбарлах чадал: φ² = {(phiCoeff * phiCoeff).toFixed(2)}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
