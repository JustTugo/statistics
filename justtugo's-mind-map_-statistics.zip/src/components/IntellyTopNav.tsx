import { Search, Network, LayoutDashboard, ListTree, Sun, Moon, Menu, Smartphone, Download } from 'lucide-react';

interface IntellyTopNavProps {
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onOpenSearchModal: () => void;
  currentView: 'dashboard' | 'mindmap' | 'list';
  onChangeView: (view: 'dashboard' | 'mindmap' | 'list') => void;
  theme: 'light' | 'dark';
  onToggleTheme: () => void;
  onOpenMobileMenu?: () => void;
  onOpenInstallModal?: () => void;
}

export const IntellyTopNav: React.FC<IntellyTopNavProps> = ({
  searchQuery,
  onSearchChange,
  onOpenSearchModal,
  currentView,
  onChangeView,
  theme,
  onToggleTheme,
  onOpenMobileMenu,
  onOpenInstallModal
}) => {
  const isDark = theme === 'dark';

  return (
    <header
      style={{
        backgroundColor: isDark ? '#161616' : '#FAF7F0',
        borderColor: isDark ? '#262626' : '#EBE5D8',
        color: isDark ? '#F5F5F5' : '#141414'
      }}
      className="h-16 px-3 sm:px-8 border-b flex items-center justify-between gap-2 sm:gap-4 shrink-0 select-none transition-colors duration-300"
    >
      {/* Mobile Hamburger Menu Toggle */}
      {onOpenMobileMenu && (
        <button
          onClick={onOpenMobileMenu}
          className="md:hidden p-2 rounded-xl text-[#777777] hover:text-white hover:bg-[#222222] transition cursor-pointer shrink-0"
          title="Цэс нээх"
          aria-label="Open navigation menu"
        >
          <Menu className="w-5 h-5" />
        </button>
      )}

      {/* Search Input with pink circle button and kbd shortcut */}
      <div
        style={{
          backgroundColor: isDark ? '#202020' : '#F0E9DF',
          borderColor: isDark ? '#333333' : '#E2D9CC'
        }}
        className="flex-1 max-w-2xl flex items-center border rounded-full px-1.5 sm:px-2 py-1 shadow-2xs min-w-0"
      >
        {/* Pink search icon button */}
        <button
          onClick={onOpenSearchModal}
          className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-[#FF6B8B] flex items-center justify-center text-white shrink-0 hover:opacity-90 transition cursor-pointer shadow-xs"
          title="Хайх (Ctrl+K)"
        >
          <Search className="w-3.5 h-3.5 stroke-[2.5]" />
        </button>

        <input
          type="text"
          value={searchQuery}
          onChange={e => onSearchChange(e.target.value)}
          onClick={onOpenSearchModal}
          placeholder="Хайх: t-тест, ANOVA, хи квадрат, SPSS, z-оноо..."
          style={{ color: isDark ? '#FFFFFF' : '#141414' }}
          className="flex-1 bg-transparent px-2 sm:px-3 text-xs placeholder-[#888888] outline-none font-medium truncate"
        />

        <div className="hidden sm:flex items-center text-[10px] font-mono text-[#888888] pr-2">
          <kbd
            style={{
              backgroundColor: isDark ? '#2D2D2D' : '#E8E2D5',
              color: isDark ? '#B0B0B0' : '#555555'
            }}
            className="px-2 py-0.5 rounded-full border border-black/10 font-bold"
          >
            ⌘K
          </kbd>
        </div>
      </div>

      {/* View Switcher Tabs (Dashboard / Mind Map / Topics) */}
      <div
        style={{
          backgroundColor: isDark ? '#222222' : '#EBE5D8'
        }}
        className="hidden md:flex items-center rounded-full p-1 text-xs"
      >
        <button
          onClick={() => onChangeView('dashboard')}
          style={{
            backgroundColor: currentView === 'dashboard' ? (isDark ? '#333333' : '#FFFFFF') : 'transparent',
            color: currentView === 'dashboard' ? (isDark ? '#FFFFFF' : '#141414') : (isDark ? '#A0A0A0' : '#666666')
          }}
          className="px-3.5 py-1.5 rounded-full transition cursor-pointer flex items-center space-x-1.5 font-semibold"
        >
          <LayoutDashboard className="w-3.5 h-3.5" />
          <span>Dashboard</span>
        </button>

        <button
          onClick={() => onChangeView('mindmap')}
          style={{
            backgroundColor: currentView === 'mindmap' ? (isDark ? '#333333' : '#FFFFFF') : 'transparent',
            color: currentView === 'mindmap' ? '#FF6B8B' : (isDark ? '#A0A0A0' : '#666666')
          }}
          className="px-3.5 py-1.5 rounded-full transition cursor-pointer flex items-center space-x-1.5 font-semibold"
        >
          <Network className="w-3.5 h-3.5 text-[#FF6B8B]" />
          <span>Mind Map</span>
        </button>

        <button
          onClick={() => onChangeView('list')}
          style={{
            backgroundColor: currentView === 'list' ? (isDark ? '#333333' : '#FFFFFF') : 'transparent',
            color: currentView === 'list' ? (isDark ? '#FFFFFF' : '#141414') : (isDark ? '#A0A0A0' : '#666666')
          }}
          className="px-3.5 py-1.5 rounded-full transition cursor-pointer flex items-center space-x-1.5 font-semibold"
        >
          <ListTree className="w-3.5 h-3.5" />
          <span>Topics (9)</span>
        </button>
      </div>

      {/* Right Controls: Android/App Install & Theme Toggle */}
      <div className="flex items-center space-x-2 shrink-0">
        {onOpenInstallModal && (
          <button
            onClick={onOpenInstallModal}
            style={{
              backgroundColor: isDark ? '#251E24' : '#FFF0F5',
              borderColor: isDark ? '#4A2A38' : '#FFD0E0',
              color: '#FF6B8B'
            }}
            className="p-1.5 sm:px-3 sm:py-1.5 rounded-full border shadow-2xs hover:scale-105 transition cursor-pointer flex items-center space-x-1.5 text-xs font-bold"
            title="Android & Утсанд суулгах"
            aria-label="Download app"
          >
            <Smartphone className="w-4 h-4 stroke-[2.2]" />
            <span className="hidden sm:inline text-[11px]">App татах</span>
          </button>
        )}

        <button
          onClick={onToggleTheme}
          style={{
            backgroundColor: isDark ? '#262626' : '#FFFFFF',
            borderColor: isDark ? '#3A3A3A' : '#E0D8C8',
            color: isDark ? '#FFD54F' : '#141414'
          }}
          className="p-2 rounded-full border shadow-2xs hover:scale-105 transition cursor-pointer"
          title={isDark ? 'Гэгээлэг горим (Light mode)' : 'Харанхуй горим (Dark mode)'}
          aria-label="Toggle theme"
        >
          {isDark ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-700" />}
        </button>
      </div>
    </header>
  );
};
