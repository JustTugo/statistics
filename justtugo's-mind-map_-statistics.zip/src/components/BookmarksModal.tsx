import React from 'react';
import { GraphNode, StudyStatus } from '../types';
import { Bookmark, X, ArrowRight, Trash2 } from 'lucide-react';

interface BookmarksModalProps {
  isOpen: boolean;
  onClose: () => void;
  bookmarks: Record<string, boolean>;
  nodesMap: Record<string, GraphNode>;
  onSelectNode: (node: GraphNode) => void;
  studyStatus: Record<string, StudyStatus>;
  onClearBookmarks: () => void;
}

export const BookmarksModal: React.FC<BookmarksModalProps> = ({
  isOpen,
  onClose,
  bookmarks,
  nodesMap,
  onSelectNode,
  studyStatus,
  onClearBookmarks
}) => {
  if (!isOpen) return null;

  const bookmarkedKeys = Object.keys(bookmarks).filter(k => bookmarks[k]);
  const bookmarkedNodes = bookmarkedKeys.map(k => nodesMap[k]).filter(Boolean);

  const understoodCount = Object.values(studyStatus).filter(s => s === 2).length;
  const studyingCount = Object.values(studyStatus).filter(s => s === 1).length;
  const totalNodesCount = Object.keys(nodesMap).length;

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-start justify-end p-4 sm:p-6 select-none"
    >
      <div
        onClick={e => e.stopPropagation()}
        className="w-full max-w-sm bg-[#FAF7F0] border border-[#202020] rounded-[28px] shadow-2xl p-5 flex flex-col max-h-[85vh]"
      >
        <div className="flex items-center justify-between pb-3 border-b border-[#EBE5D8]">
          <div className="text-xs font-bold text-[#141414] flex items-center space-x-2">
            <Bookmark className="w-4 h-4 text-amber-500 fill-amber-500" />
            <span>Хадгалсан сэдвүүд ({bookmarkedNodes.length})</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-[#777777] hover:text-[#141414] transition rounded-full cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Study progress bar */}
        <div className="py-3 px-3.5 my-3 bg-white rounded-2xl border border-[#EBE5D8] text-xs font-mono space-y-1.5 shadow-2xs">
          <div className="flex justify-between text-[#666666]">
            <span>Нийт судалсан явц:</span>
            <span className="text-[#141414] font-bold">{understoodCount} ойлгосон</span>
          </div>
          <div className="w-full bg-[#EBE5D8] rounded-full h-2 overflow-hidden">
            <div
              className="bg-[#A8C57C] h-full rounded-full transition-all duration-500"
              style={{
                width: `${Math.round((understoodCount / Math.max(1, totalNodesCount)) * 100)}%`
              }}
            />
          </div>
          <div className="flex justify-between text-[10px] text-[#888888]">
            <span>Судалж буй: {studyingCount}</span>
            <span>{Math.round((understoodCount / Math.max(1, totalNodesCount)) * 100)}%</span>
          </div>
        </div>

        {/* Bookmarked list */}
        <div className="flex-1 overflow-y-auto space-y-2 py-2">
          {bookmarkedNodes.length === 0 ? (
            <div className="py-8 text-center text-xs text-[#888888] space-y-2">
              <Bookmark className="w-8 h-8 mx-auto text-[#CCCCCC] stroke-1" />
              <p>Одоогоор хадгалсан сэдэв алга байна.</p>
            </div>
          ) : (
            bookmarkedNodes.map(node => (
              <div
                key={node.i}
                className="p-3 rounded-2xl bg-white hover:bg-[#F2ECE1] border border-[#EBE5D8] transition flex items-center justify-between group"
              >
                <div
                  onClick={() => {
                    onSelectNode(node);
                    onClose();
                  }}
                  className="cursor-pointer flex-1 truncate pr-2"
                >
                  <div className="text-xs font-bold text-[#141414] truncate">
                    {node.t}
                  </div>
                  {node.e && (
                    <div className="text-[10px] font-mono text-[#777777] truncate">
                      {node.e}
                    </div>
                  )}
                </div>

                <button
                  onClick={() => {
                    onSelectNode(node);
                    onClose();
                  }}
                  className="p-1.5 rounded-full hover:bg-black hover:text-white text-[#777777] transition cursor-pointer"
                >
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            ))
          )}
        </div>

        {bookmarkedNodes.length > 0 && (
          <div className="pt-3 border-t border-[#EBE5D8] mt-2">
            <button
              onClick={onClearBookmarks}
              className="w-full py-2 rounded-full border border-[#D9D0C0] hover:bg-[#EBE5D8] text-xs font-semibold text-[#888888] hover:text-[#141414] transition cursor-pointer flex items-center justify-center space-x-1"
            >
              <Trash2 className="w-3 h-3" />
              <span>Бүгдийг арилгах</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
