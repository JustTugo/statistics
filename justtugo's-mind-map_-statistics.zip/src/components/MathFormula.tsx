import React, { useEffect, useRef } from 'react';
import katex from 'katex';

interface MathFormulaProps {
  formula: string;
  displayMode?: boolean;
  className?: string;
}

export const MathFormula: React.FC<MathFormulaProps> = ({ formula, displayMode = true, className = '' }) => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (containerRef.current) {
      try {
        katex.render(formula, containerRef.current, {
          throwOnError: false,
          displayMode
        });
      } catch (err) {
        console.error('KaTeX rendering error:', err);
        containerRef.current.textContent = formula;
      }
    }
  }, [formula, displayMode]);

  return <div ref={containerRef} className={`overflow-x-auto ${className}`} />;
};
